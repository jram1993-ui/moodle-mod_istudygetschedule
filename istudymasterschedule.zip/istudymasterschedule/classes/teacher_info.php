<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * @package    mod_istudymasterschedule
 * @copyright  2024 Jesus Ramirez <jram1993@gmail.com>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace mod_istudymasterschedule;

use stdClass;

/**
 * Class teacher_info
 *
 * @package    mod_istudymasterschedule
 * @copyright  2024 Jesus Ramirez <jram1993@gmail.com>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class teacher_info {
    /**
      * Print the master schedule for all teachers.
      *
      * @param [integer] $school_term
      * @param [boolean] $school_include_course_name
      * @return void
      */
    public static function get_all_advisor_courses($school_term, $school_include_course_name) {

        $week_day[1] = 'monday';
        $week_day[2] = 'tuesday';
        $week_day[3] = 'wednesday';
        $week_day[4] = 'thursday';
        $week_day[5] = 'friday';
        $number_of_sessions = get_config('mod_istudy', 'number_of_sessions');
        $daily_totals = array(1=>0, 2=>0, 3=>0, 4=>0, 5=>0);
        $all_students = new stdClass();

        $school_advisors = utils::get_advisor_list();

        /**
         * Variable to store html information for the final total printout.
         */
        $print_totals = '';

        foreach ($school_advisors as $school_advisor) {

            $mystudent_list[][] = new stdClass();
            $duplicate_student_count_id[] = array();
            $duplicate_student_count_course_number[] = array();
            $count = 0;

            /**
             * Initialize the table row for the teacher totals
             */
            $print_totals = $print_totals . '<tr><td class="cellborderright">' . utils::put_comma_in_name($school_advisor) . '</td>';
            /**
             * Get all of the students for the specified teacher.
             */
            for ($myday = 1; $myday <= 5; $myday++) {
                for ($mysession = 1; $mysession <= $number_of_sessions; $mysession++) {
                    $mystudent_list[$myday][$mysession]='';
                    $session_count = 0;

                    //
                    /**
                     *  Get the students names.Find all students that have the teacher on the day of the week and during current session.
                     *  @var object all_students
                     */
                    $all_students = student_info::students_by_session($mysession, $school_advisor, $school_term, $myday);
                    if ($all_students[0]->student_name <> 'No Students Found') {
                        foreach ($all_students as $all_student) {
                            $duplicate_student = false;
                            if ($count > 0) {
                                for ($i = 1; $i <= $count; $i++) {
                                    if ($duplicate_student_count_id[$i] == $all_student->id AND $duplicate_student_count_course_number[$i] == $all_student->courseid) {
                                        $duplicate_student = true;
                                    }
                                }
                            }

                            /**
                             * For distance learning students (100% of the time), change color of the text and background.
                             */
                            $distance_learning_yes = '';
                            $distance_learning_only = utils::get_field_data($all_student->id, utils::get_fieldid('distancelearningonly'));
                            if ($distance_learning_only == 'Yes'){
                                $distance_learning_yes = ' style="color:White; background-color:Gray;"';
                            }

                            if ($duplicate_student) {
                                $student_name = '<u' . $distance_learning_yes . '>' . $all_student->student_name . ' (' . $all_student->grade . ')</u>';
                            }
                            else {
                                $student_name = '<b' . $distance_learning_yes . '>' . $all_student->student_name . ' (' . $all_student->grade . ')</b>';
                                $count = $count + 1;
                                $session_count = $session_count + 1;
                                $duplicate_student_count_id[$count] = $all_student->id;
                                $duplicate_student_count_course_number[$count]= $all_student->courseid;
                            }
                            $mystudent_list[$myday][$mysession] = $mystudent_list[$myday][$mysession] . $student_name . '<br>';
                            if ($school_include_course_name) {
                                $mystudent_list[$myday][$mysession] = $mystudent_list[$myday][$mysession] . '<i>' . $all_student->course_name;
                                $mystudent_list[$myday][$mysession] = $mystudent_list[$myday][$mysession] . ' [' . $all_student->credits . ' credits]' . '</i></br>';
                            }
                        }
                    }
                    if ($mystudent_list[$myday][$mysession]=='') { $mystudent_list[$myday][$mysession]='None'; }
                    $daily_totals[$myday] = $daily_totals[$myday] + $session_count;
                    // Print the session total with a thick border on the right if it's the last session
                    if ($mysession == $number_of_sessions) {
                        $print_totals = $print_totals . '<td class="cellborderright">' . $session_count . '</td>';
                    }
                    else {
                        $print_totals = $print_totals . '<td>' . $session_count . '</td>';
                    }
                }
            }
            utils::master_schedule($mystudent_list, $school_term, $school_advisor);
            $print_totals = $print_totals . '<td>' . $count . '</td></tr>';
        }

        /**
         * Print the sheet with the totals
         */
        utils::class_totals($print_totals, $daily_totals, $school_term);

        return;
    }

    /**
     * Print the master schedule for one teacher.
     *
     * @param [integer] $school_advisor
     * @param [integer] $school_term
     * @param [boolean] $school_include_course_name
     * @return void
     */
    public static function get_advisor_courses($school_advisor, $school_term, $school_include_course_name) {

        $mystudent_list[][] = array();
        $duplicate_student_count_id[] = array();
        $duplicate_student_count_course_number[] = array();
        $count = 0;

        $week_day[1] = 'monday';
        $week_day[2] = 'tuesday';
        $week_day[3] = 'wednesday';
        $week_day[4] = 'thursday';
        $week_day[5] = 'friday';
        $number_of_sessions = get_config('mod_istudy', 'number_of_sessions');

        /**
         * Get all of the students for the specified teacher.
         */
        for ($myday = 1; $myday <= 5; $myday++) {
            for ($mysession = 1; $mysession <= $number_of_sessions; $mysession++) {
                $mystudent_list[$myday][$mysession]='';

                /**
                 * Get the students names by finding all students that have the teacher on the day of the week and during current session.
                 *  @var object all_students
                 */
                $all_students = student_info::students_by_session($mysession, $school_advisor, $school_term, $myday);
                if ($all_students[0]->student_name <> 'No Students Found') {
                    foreach ($all_students as $all_student) {
                        /**
                         * Check to see if student is a duplicate_student_count
                         */
                        $duplicate_student = false;
                        if ($count > 0) {
                            for ($i = 1; $i <= $count; $i++) {
                                if ($duplicate_student_count_id[$i] == $all_student->id AND $duplicate_student_count_course_number[$i] == $all_student->courseid) {
                                    $duplicate_student = true;
                                }
                            }
                        }

                        /**
                         * If distance learning students (100% of the time), change color of the text and background.
                         */
                        $distance_learning_yes = '';
                        $distance_learning_only = utils::get_field_data($all_student->id, utils::get_fieldid('distancelearningonly'));
                        if ($distance_learning_only == 'Yes'){
                            $distance_learning_yes = ' style="color:White; background-color:Gray;"';
                        }

                        if ($duplicate_student) {
                            $student_name = '<u' . $distance_learning_yes . '>' . $all_student->student_name . ' (' . $all_student->grade . ')</u>';
                        }
                        else {
                            $student_name = '<b' . $distance_learning_yes . '>' . $all_student->student_name . ' (' . $all_student->grade . ')</b>';
                            $count = $count + 1;
                            $duplicate_student_count_id[$count] = $all_student->id;
                            $duplicate_student_count_course_number[$count]= $all_student->courseid;
                        }
                        $mystudent_list[$myday][$mysession] = $mystudent_list[$myday][$mysession] . $student_name . '<br>';
                        if ($school_include_course_name) {
                            $mystudent_list[$myday][$mysession] = $mystudent_list[$myday][$mysession] . '<i>' . $all_student->course_name;
                            $mystudent_list[$myday][$mysession] = $mystudent_list[$myday][$mysession] . ' [' . $all_student->credits . ' credits]' . '</i></br>';
                        }
                    }
                }
                if ($mystudent_list[$myday][$mysession]=='') { $mystudent_list[$myday][$mysession]='None'; }
            }
        }
        utils::master_schedule($mystudent_list, $school_term, $school_advisor);
        return;
    }
}