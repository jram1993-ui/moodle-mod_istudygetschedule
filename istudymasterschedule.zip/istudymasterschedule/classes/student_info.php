<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * @package    mod_istudymasterschedule
 * @copyright  2024 Jesus Ramirez <jram1993@gmail.com>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace mod_istudymasterschedule;

use stdClass;

/**
 * Class student_info
 *
 * @package    mod_istudymasterschedule
 * @copyright  2024 Jesus Ramirez <jram1993@gmail.com>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class student_info {
    /**
     * Get all of the students for the advisor by day of the week (Monday-Friday)
     *
     * @param [integer] $this_session
     * @param [integer] $school_advisor
     * @param [integer] $school_term
     * @param [integer] $school_day_of_week
     * @return void
     */
    public static function students_by_session($this_session, $school_advisor, $school_term, $school_day_of_week) {
        global $DB;

        $mystudent_list[] = array();
        $temp_info = new stdClass();
        $count = -1;

        $week_day[1] = 'monday';
        $week_day[2] = 'tuesday';
        $week_day[3] = 'wednesday';
        $week_day[4] = 'thursday';
        $week_day[5] = 'friday';
        $this_school_term = utils::get_term($school_term);
        $advisor_name = $school_advisor;

        /**
         * Check for a daily schedule. If 'No', student schedules are different each day of the week.
         * If 'Yes', Mondays schedule is applied to each day of the week (Monday-Friday).
         */
        if ($school_term == 1 OR $school_term == 2) {
            $dailyschedule = get_config('mod_istudy', 'dailyschedule');
        }
        else {
            $dailyschedule = get_config('mod_istudy', 'summer_dailyschedule');
        }
        if ($dailyschedule == 'Yes') {
            $school_day_of_week = 1;
        }

        /**
         * Get all students that have the teacher according to day of the week and session.
         */
        $name_of_session = $this_school_term . $week_day[$school_day_of_week] . 'session' .  $this_session;
        $name_of_session_credits = $this_school_term . $week_day[$school_day_of_week] . 'creditssession' .  $this_session;
        $course_id = utils::get_fieldid($name_of_session);
        $select = "SELECT * FROM {user_info_data} WHERE fieldid = " . $course_id . " AND data LIKE '%" . $advisor_name . "%'";
        $mystudents = $DB->get_records_sql($select, null, 0,0);

        /**
         * Get the data that identifies the student.
         */
        foreach ($mystudents as $mystudent) {
            $temp_info = new stdClass();
            $temp_info = utils::get_student_info($mystudent->userid, $name_of_session, $name_of_session_credits);

            /**
             * Don't include students that have been deleted or suspended.
             * @var [object] $temp_info
             */
            if (($temp_info->deleted == false) and ($temp_info->suspended == false)){
                $count = $count + 1;
                $mystudent_list[$count] = new stdClass();
                $mystudent_list[$count]->id = $mystudent->userid;
                $mystudent_list[$count]->school_id = $temp_info->school_id;
                $mystudent_list[$count]->student_name = $temp_info->student_name;
                $mystudent_list[$count]->grade = $temp_info->grade;
                $mystudent_list[$count]->courseid = $temp_info->courseid;
                $mystudent_list[$count]->course_name = $temp_info->course_name;
                $mystudent_list[$count]->credits = $temp_info->credits;
            }
        }

        /**
         * If no students were found, then return.
         */
        if ($count == -1) {
            $mystudent_list[0] = new stdClass();
            $mystudent_list[0]->id = 0;
            $mystudent_list[0]->school_id = '0';
            $mystudent_list[0]->student_name = 'No Students Found';
            $mystudent_list[0]->grade = 'F';
            $mystudent_list[0]->courseid = '0';
            $mystudent_list[0]->course_name = 'None';
            $mystudent_list[0]->credits = '0';
            return $mystudent_list;
        }

        /**
         * Sort the list by student ID.
         */
        for ($i=0; $i<=$count; $i++){
            $val = $mystudent_list[$i];
            $j = $i-1;
            while($j>=0 && $mystudent_list[$j]->school_id > $val->school_id){
                $mystudent_list[$j+1] = $mystudent_list[$j];
                $j--;
            }
            $mystudent_list[$j+1] = $val;
        }

        /**
         * Sort by student name in alphabetical order.
         */
        for ($i=0; $i<=$count; $i++){
            $val = $mystudent_list[$i];
            $j = $i-1;
            while($j>=0 && $mystudent_list[$j]->student_name > $val->student_name){
                $mystudent_list[$j+1] = $mystudent_list[$j];
                $j--;
            }
            $mystudent_list[$j+1] = $val;
        }
        return $mystudent_list;
    }
}