<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * @package    mod_istudymasterschedule
 * @copyright  2024 Jesus Ramirez <jram1993@gmail.com>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace mod_istudymasterschedule;

use stdClass;

/**
 * Class utils
 *
 * @package    mod_istudymasterschedule
 * @copyright  2024 Jesus Ramirez <jram1993@gmail.com>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class utils {

    /**
     * Gets the advisor ($myteacher) room number.
     *
     * @param [type] $myteacher
     * @return void
     */
    public static function get_advisor_room($myteacher) {
        global $DB;
        // Separate the first name and last name that are joined with a dash (-).
        $teacher_lastname = strstr($myteacher, '-', true);
        $myteacher_temp = strstr($myteacher, '-');
        $teacher_firstname = substr($myteacher_temp, 1);
        $this_teacher = new stdClass();
        $sql = "SELECT * FROM {istudyteachers} WHERE lastname = '" .  $teacher_lastname . "' AND firstname = '" .  $teacher_firstname . "'";
        $params = null;
        $this_teacher = $DB->get_record_sql($sql, $params);
        return $this_teacher->room;
    }

    /**
     * Return the course information: subject, teacher, section number, and room number.
     *
     * @param [string] $mycourse
     * @return [object] $course_info
     */
    public static function get_mycourse($mycourse) {
        $course_info = new stdClass();
        $course_info->subject = strstr($mycourse, '/', true);
        $mycourse = strstr($mycourse, "/");
        $mycourse = substr($mycourse, 1);
        $course_info->teacher = strstr($mycourse, '/', true);
        $mycourse = strstr($mycourse, "/");
        $mycourse = substr($mycourse, 1);
        $course_info->section = trim($mycourse);
        $course_info->room = utils::get_advisor_room($course_info->teacher);
        return $course_info;
    }

    /**
     * Calculate the grade level from the graduation year.
     *
     * @param [integer] $grad_year
     * @return [integer] $my_grade_level
     */
    public static function get_gradelevel($grad_year) {
        $currentmonth = date('m');
        $currentyear = date('Y');
        if ($grad_year <= $currentyear) {
            $years_left = 0;
        }
        else if ($currentmonth > 7) {
            $years_left = $grad_year - ($currentyear + 1);
        }
        else {
            $years_left = $grad_year - $currentyear;
        }
        $my_grade_level = 12 - $years_left;
        return $my_grade_level;
    }

    /**
     * Get the school year according to the term.
     *
     * @param [string] $school_term
     * @return [integer]
     */
    public static function get_schoolyear($school_term) {
        /**
         * Find the beginning and the end of the current school year.
         */
        $month_today = strval(date("m"));
        if ($month_today >= 8) {
            $year_start = strval(date("Y"));
        }
        else {
            $year_start = strval(date("Y")) - 1;
        }
        $year_end = $year_start + 1;
        if ($school_term == 'fall' OR $school_term == 'Fall') {
            return $year_start;
        }
        else {
            return $year_end;
        }
    }

    /**
     * Get the user_info_field id to use in searching user_info_data
     *
     * @param [string] $item_name
     * @return [integer]
     */
    public static function get_fieldid($item_name) {
        global $DB;
        $item = $DB->get_record('user_info_field', ['shortname' => $item_name], 'id');
        return $item->id;
    }

    /**
     * Search user_info_data for student data using the student id and user_info_field id.
     *
     * @param [integer] $student_id
     * @param [integer] $itemid
     * @return [string]
     */
    public static function get_field_data($student_id, $itemid) {
        global $DB;
        if ($DB->record_exists('user_info_data', ['userid'=>$student_id, 'fieldid'=>$itemid])) {
            $search_results = $DB->get_record('user_info_data', ['userid'=>$student_id, 'fieldid'=>$itemid], 'data');
            return $search_results->data;
        }
        else {
            return '';
        }
    }

    /**
     * Replace the dash in the advisor name with a comma and a space.
     *
     * @param [string] $myteacher
     * @return [string]
     */
    public static function put_comma_in_name($myteacher) {
        $postion = strrpos($myteacher,"-");
        $name_with_dash = substr($myteacher, $postion);
        $name_with_comma = ', ' . substr($name_with_dash,1);
        $new_name = str_replace($name_with_dash,$name_with_comma,$myteacher);
        return $new_name;
    }

    /**
     * Get a single advisor.
     *
     * @param [integer] $chosen_advisor
     * @return [string]
     */
    public static function get_advisor($chosen_advisor) {
        global $DB;
        $sql = "SELECT * FROM {istudyteachers} ORDER By lastname ASC, firstname ASC";
        $params = null;
        $all_advisors = $DB->get_records_sql($sql, $params);
        $advisor = [];
        $count = 0;
        $advisor[$count] = 'All';
        // Create the list of advisors
       foreach ($all_advisors as $this_advisor) {
            $count = $count + 1;
            $teacher_lastname = $this_advisor->lastname;
            $teacher_firstname = $this_advisor->firstname;
            $advisor[$count] = $teacher_lastname . '-' . $teacher_firstname;
        }
        // Return the advisor.
        return $advisor[$chosen_advisor];
    }

    // **Get a list of all advisors or teachers.
    public static function get_advisors() {
        global $DB;
        $sql = "SELECT * FROM {istudyteachers} ORDER By lastname ASC, firstname ASC";
        $params = null;
        $all_advisors = $DB->get_records_sql($sql, $params);
        $count = 0;
        $advisor[$count] = 'All';
        foreach ($all_advisors as $this_advisor) {
            $count++;
            $advisor[$count] = $this_advisor->lastname . '-' . $this_advisor->firstname;
        }
        return $advisor;
    }

    // Get the name of the advisor.
    public static function get_advisor_name($advisorid) {
        global $DB;
        $this_teacher = new stdClass();
        $sql = "SELECT * FROM {istudyteachers} WHERE teacherid = '" . $advisorid . "'";
        $params = null;
        $this_teacher = $DB->get_record_sql($sql, $params);
        $advisor_name = $this_teacher->lastname . '-' . $this_teacher->firstname;
        return $advisor_name;
    }

    /**
     * Get the default adivsor.
     *
     * @param [string] $advisors_list array
     * @return [integer]
     */
    public static function get_default_advisor($advisors_list) {
        global $USER;

        $advisorid = $USER->id;
        $current_advisor = utils::get_field_data($advisorid, utils::get_fieldid('whichteacher'));
        if ($current_advisor == "Administrator" OR $current_advisor == "Parent") {
            return 0;
        }
        else {
            $default_advisor = 0;
            $count = 0;
            $current_advisor = utils::get_advisor_name($USER->id);
            foreach ($advisors_list as $advisor_list) {
                $count = $count + 1;
                if (trim($advisor_list) == trim($current_advisor)) {
                    $default_advisor = $count;
                }
            }
            return ($default_advisor - 1);
        }
    }

     /**
     * Get a list of all advisors without 'All'.
     *
     * @return [string array]
     */
    public static function get_advisor_list() {
        global $DB;
        $sql = "SELECT * FROM {istudyteachers} ORDER By lastname ASC, firstname ASC";
        $params = null;
        $all_advisors = $DB->get_records_sql($sql, $params);
        $count = 0;
        foreach ($all_advisors as $this_advisor) {
            $count++;
            $advisor[$count] = $this_advisor->lastname . '-' . $this_advisor->firstname;
        }
        return $advisor;
    }

    /**
     * Return the term chosen: 1=fall, 2=spring, or 3=summer.
     *
     * @param [integer] $term_choice
     * @return [string]
     */
    public static function get_term($term_choice) {
        $schoolterms[1] = 'fall';
        $schoolterms[2] = 'spring';
        $schoolterms[3] = 'summer';
        return $schoolterms[$term_choice];
    }

    /**
     * Return the term chosen with the first letter capitalized: 1=Fall, 2=Spring, or 3=Summer.
     *
     * @param [integer] $term_choice
     * @return [string]
     */
    public static function get_term_with_cap($term_choice) {
        $schoolterms[1] = 'Fall';
        $schoolterms[2] = 'Spring';
        $schoolterms[3] = 'Summer';
        return $schoolterms[$term_choice];
    }

    /**
     * Get student personal information.
     *
     * @param [integer] $student_id
     * @param [type] $schoolterm ?????
     * @param [type] $day_of_week ?????
     * @param [string] $name_of_session
     * @param [string] $name_of_session_credits
     * @return void
     */
    public static function get_student_info($student_id, $name_of_session, $name_of_session_credits) {
        global $DB;
        // Get the student info.
        $student_info = new stdClass();
        $student_info->id = $student_id;
        $student_info->school_id = utils::get_field_data($student_id, utils::get_fieldid('schoolid'));
        $student_temp = $DB->get_record('user', ['id' => $student_id] , 'firstname, lastname, deleted, suspended');
        $student_info->student_name = $student_temp->lastname . ', ' . $student_temp->firstname;
        $student_info->deleted = $student_temp->deleted;
        $student_info->suspended = $student_temp->suspended;
        // Find the course and break it up into its components -- example: Spanish IA/Ramirez-Jesus/650512/304
        $this_course_temp =  utils::get_mycourse(utils::get_field_data($student_id, utils::get_fieldid($name_of_session)));
        $student_info->courseid = $this_course_temp->section;
        $student_info->course_name = $this_course_temp->subject;
        $student_info->teacher = $this_course_temp->teacher;
        $student_info->credits = utils::get_field_data($student_id, utils::get_fieldid($name_of_session_credits));
        $student_info->grade = utils::get_gradelevel(utils::get_field_data($student_id, utils::get_fieldid('graduationyear')));
        return $student_info;
    }

    /**
     * Print the advisor master schedule for a specific teacher (Monday-Friday).
     *
     * @param [object] $mystudents
     * @param [text] $school_term
     * @param [text] $school_advisor
     * @return void
     */
    public static function master_schedule($mystudents, $school_term, $school_advisor) {
        $week_day[1] = 'monday';
        $week_day[2] = 'tuesday';
        $week_day[3] = 'wednesday';
        $week_day[4] = 'thursday';
        $week_day[5] = 'friday';
        $number_of_sessions = get_config('mod_istudy', 'number_of_sessions');

        /**
         * Get the start and end times for each session.
         */
        $summer = '';
        if ($school_term == 'Summer') {$summer = 'summer_';}
        $time_session[][] = array() ;
        for ($d = 1; $d <= 5; $d++) {
            for ($t = 1; $t <= $number_of_sessions; $t++) {
                $time_session1[$d][$t] = get_config('mod_istudy', $summer . $week_day[$d] . 'session' . $t);
            }
        }

        /**
         * Print the page title with the school name and other information.
         */
        $advisor_info = '<link rel="stylesheet" type="text/css" href="styles-print_students.css"><html><head><title>' .  utils::put_comma_in_name($school_advisor) . '</title></head><h1>' .
                            get_config('mod_istudy', 'schoolname') . '</h1><h2>' . utils::get_term_with_cap($school_term) . ' Master Schedule - ' . date("m/d/Y") . '</h2><h3>' . utils::put_comma_in_name($school_advisor) . '</h3><br>';

        /**
         * Create the table heading.
         */
        $advisor_info = $advisor_info . '<table><tr>' .
            '<th width="20%" class="cellborderall">MONDAY</th><th width="20%" class="cellborderall">TUESDAY</th><th width="20%" class="cellborderall">WEDNESDAY</th>' .
            '<th width="20%" class="cellborderall">THURSDAY</th><th width="20%" class="cellborderall">FRIDAY</th></tr>';
        for ($t = 1; $t <= $number_of_sessions; $t++) {
            $advisor_info = $advisor_info . '<tr><td  valign="top" class="mycell"><b>P' . $t . '~ </b> ' . $time_session1[1][$t] . '</td><td  valign="top" class="mycell"><b>P' . $t . '~ </b> ' .
                $time_session1[2][$t] . '</td><td  valign="top" class="mycell"><b>P' . $t . '~ </b> ' . $time_session1[3][$t] . '</td><td  valign="top" class="mycell"><b>P' . $t . '~ </b> ' .
                $time_session1[4][$t] . '</th><td  valign="top" class="mycell"><b>P' . $t . '~ </b> ' . $time_session1[5][$t] . '</td></tr>';
            $advisor_info = $advisor_info . '<tr>';
            for ($d = 1; $d <= 5; $d++) {
                $advisor_info = $advisor_info . '<td  valign="top" class="mycell3">' . $mystudents[$d][$t] . '</td>';
            }
            $advisor_info = $advisor_info . '</tr>';
        }
        $advisor_info = $advisor_info . '</table></html>';

        /**
         * Print the master schedule for this advisor.
         */
        $advisor_print_newtab = "<script>
                var newWindow = window.open('');
                newWindow.document.write('$advisor_info');
            </script>";
        echo $advisor_print_newtab;

        return;
    }

    /**
     * Print the total number of students that each teacher has.
     *
     * @param [integer] $print_totals
     * @param [integer] $daily_totals
     * @param [text] $school_term
     * @return void
     */
    public static function class_totals($print_totals, $daily_totals, $school_term) {

        $number_of_sessions = get_config('mod_istudy', 'number_of_sessions');

        /**
         * Print the page title with the school name and other information.
         */
        $advisor_info = '<link rel="stylesheet" type="text/css" href="styles-print_students.css"><html><head><title>Totals</title><h1>' .
                            get_config('mod_istudy', 'schoolname') . '</h1><h2>' . utils::get_term_with_cap($school_term) . ' Master Schedule</h2><h3>All Teachers</h3>';

        /**
         * Create the table heading.
         */
        $advisor_info = $advisor_info . '<table><tr><th class="cellborderall">TEACHER</th><th colspan="' . $number_of_sessions . '" class="cellborderall">MONDAY</th>' .
            '<th colspan="' . $number_of_sessions . '" class="cellborderall">TUESDAY</th><th colspan="' . $number_of_sessions . '" class="cellborderall">WEDNESDAY</th>' .
            '<th colspan="' . $number_of_sessions . '" class="cellborderall">THURSDAY</th><th colspan="' . $number_of_sessions . '" class="cellborderall">FRIDAY</th>' .
            '<th class="cellborderall">Totals</th></tr>';
        /**
         * Create the titles for each session (Monday-Friday).
         */
        $advisor_info = $advisor_info . '<tr><th class="cellborderright"></th>';
        for ($i = 1; $i <= 5; $i++) {
            for ($j = 1; $j < $number_of_sessions; $j++) {
                $advisor_info = $advisor_info . '<th>' . $j . '</th>';
            }
            $advisor_info = $advisor_info . '<th class="cellborderright">' . $number_of_sessions . '</th>';
        }
        $advisor_info = $advisor_info . '<th></th></tr>';

        /**
         * Include the advisor session totals.
         */
        $advisor_info = $advisor_info . $print_totals;
        /**
         * Include the totals for each day of the week.
         */
        $allstudent_total = $daily_totals[1] + $daily_totals[2] + $daily_totals[3] + $daily_totals[4] + $daily_totals[5];
        $advisor_info = $advisor_info . '<tr><td class="cellborderall">Day Totals</td><td colspan="' . $number_of_sessions . '" class="cellborderall">' . $daily_totals[1] . '</td>' .
            '<td colspan="' . $number_of_sessions . '" class="cellborderall">' . $daily_totals[2] . '</td><td colspan="' . $number_of_sessions . '" class="cellborderall">' . $daily_totals[3] . '</td>' .
            '<td colspan="' . $number_of_sessions . '" class="cellborderall">' . $daily_totals[4] . '</td><td colspan="' . $number_of_sessions . '" class="cellborderall">' . $daily_totals[5] . '</td>' .
            '<td class="cellborderall"><b>' . $allstudent_total . '</b></td></tr>';


        $advisor_info = $advisor_info . '</table></html>';

        /**
         * Print the total number of students for each advisor by day of the week and session.
         */
        $masterschedule_print_newtab = "<script>
                var newWindow = window.open('');
                newWindow.document.write('$advisor_info');
            </script>";
        echo $masterschedule_print_newtab;

        return;
    }
}