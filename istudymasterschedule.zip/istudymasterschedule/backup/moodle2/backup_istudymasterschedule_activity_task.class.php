<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Defines backup_istudymasterschedule_activity_task class
 *
 * @package     mod_istudymasterschedule
 * @category    backup
 * @copyright   2024 Jesus Ramirez <jram1993@gmail.com>
 * @license     http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die;

require_once($CFG->dirroot . '/mod/istudymasterschedule/backup/moodle2/backup_istudymasterschedule_stepslib.php');

/**
 * Provides the steps to perform one complete backup of the istudymasterschedule instance
 *
 * @package   mod_istudymasterschedule
 * @category  backup
 * @copyright 2024 Jesus Ramirez <jram1993@gmail.com>
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class backup_istudymasterschedule_activity_task extends backup_activity_task {

    /**
     * Defines particular settings for the plugin.
     */
    protected function define_my_settings() {
    }

    /**
     * Defines particular steps for the backup process.
     */
    protected function define_my_steps() {
        $this->add_step(new backup_istudymasterschedule_activity_structure_step('istudymasterschedule_structure', 'istudymasterschedule.xml'));
    }

    /**
     * Codes the transformations to perform in the activity in order to get transportable (encoded) links.
     *
     * @param string $content
     * @return string
     */
    static public function encode_content_links($content) {
        global $CFG;

        $base = preg_quote($CFG->wwwroot, '/');

        // Link to the list of istudymasterschedules.
        $search = '/('.$base.'\/mod\/istudymasterschedule\/index.php\?id\=)([0-9]+)/';
        $content = preg_replace($search, '$@ISTUDYMASTERSCHEDULEINDEX*$2@$', $content);

        // Link to istudymasterschedule view by moduleid.
        $search = '/('.$base.'\/mod\/istudymasterschedule\/view.php\?id\=)([0-9]+)/';
        $content = preg_replace($search, '$@ISTUDYMASTERSCHEDULEVIEWBYID*$2@$', $content);

        return $content;
    }
}