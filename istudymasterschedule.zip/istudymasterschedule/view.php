<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Prints an instance of mod_istudymasterschedule.
 *
 * @package    mod_istudymasterschedule
 * @copyright  2024 Jesus Ramirez <jram1993@gmail.com>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

require(__DIR__.'/../../config.php');
require_once(__DIR__.'/lib.php');
require_once(__DIR__.'/search_criteria_form.php');

global $DB;

/**
 * Course module id.
 */
$id = optional_param('id', 0, PARAM_INT);

/**
 * Activity instance id.
 */
$i = optional_param('i', 0, PARAM_INT);

if ($id) {
    $cm = get_coursemodule_from_id('istudymasterschedule', $id, 0, false, MUST_EXIST);
    $course = $DB->get_record('course', array('id' => $cm->course), '*', MUST_EXIST);
    $moduleinstance = $DB->get_record('istudymasterschedule', array('id' => $cm->instance), '*', MUST_EXIST);
} else {
    $moduleinstance = $DB->get_record('istudymasterschedule', array('id' => $i), '*', MUST_EXIST);
    $course = $DB->get_record('course', array('id' => $moduleinstance->course), '*', MUST_EXIST);
    $cm = get_coursemodule_from_instance('istudymasterschedule', $moduleinstance->id, $course->id, false, MUST_EXIST);
}
$istudymasterscheduleid = $cm->instance;

require_login($course, true, $cm);

$modulecontext = context_module::instance($cm->id);

$event = \mod_istudymasterschedule\event\course_module_viewed::create(array(
    'objectid' => $moduleinstance->id,
    'context' => $modulecontext
));
$event->add_record_snapshot('course', $course);
$event->add_record_snapshot('istudymasterschedule', $moduleinstance);
$event->trigger();

$PAGE->set_url('/mod/istudymasterschedule/view.php', array('id' => $cm->id));
$PAGE->set_title(format_string($moduleinstance->name));
$PAGE->set_heading(format_string($course->fullname));
$PAGE->set_context($modulecontext);

echo $OUTPUT->header();
$mform = new mod_istudymasterschedule_search_criteria_form();
$mform->set_data($istudymasterscheduleid);
if ($mform->is_cancelled()) {
	/**
	 * Cancelled forms redirect to the course main page.
	 */
	$url = new moodle_url('/course/view.php', array('id' => $course->id));
	redirect($url, 'Returning to Course Page', 1);
} else if ($data = $mform->get_data()) {
	$school_term = file_get_submitted_draft_itemid('schoolterm');
	$school_advisor = \mod_istudymasterschedule\utils::get_advisor(file_get_submitted_draft_itemid('advisor'));
	$school_include_course_name = file_get_submitted_draft_itemid('yes_or_no');
	if ($school_advisor <> 'All') {
		\mod_istudymasterschedule\teacher_info::get_advisor_courses($school_advisor, $school_term, $school_include_course_name);
	}
	else {
		\mod_istudymasterschedule\teacher_info::get_all_advisor_courses($school_term, $school_include_course_name);
	}
	$data->advisor = 0;
	echo $OUTPUT->notification('YOUR DOCUMENT HAS BEEN PRINTED - If it did not print, please turn off your popup blocker for this site', 'notifysuccess');
} else {
	/**
	 * Form has not been submitted or there was an error.
	 * Just display the form.
	 */
	$mform->set_data(array('id' => $id));
}
$PAGE->set_title(format_string($course->fullname));
$PAGE->set_heading(format_string($course->fullname));

$mform->display();
echo $OUTPUT->footer();