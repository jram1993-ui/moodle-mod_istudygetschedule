<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 *
 * @package    mod_istudymasterschedule
 * @copyright  2024 Jesus Ramirez <jram1993@gmail.com>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

require_once($CFG->dirroot.'/lib/formslib.php');

/**
 * class mod_istudymasterschedule_search_criteria_form
 *
 * @package    mod_istudymasterschedule
 * @copyright  2024 Jesus Ramirez <jram1993@gmail.com>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class mod_istudymasterschedule_search_criteria_form extends \moodleform {
    public function definition()
	{
		$mform = $this->_form;
		$mform->addElement('html', '<link rel="stylesheet" type="text/css" href="styles-search_criteria_form.css">');
		$mform->addElement('html', '<table><tr><th colspan="2"><h1>Master Schedule</h1>');
		$mform->addElement('html', '<h2>Refine Your Search</h2></th></tr>');

		/**
		 * Choose the term that you are printing from
		 */
		$defaultterm_set = get_config('mod_istudy','schoolterm');
		if ($defaultterm_set == 'Fall') { $defaultterm = 1; }
		else if ($defaultterm_set == 'Spring') { $defaultterm = 2; }
		else { $defaultterm = 3; };
		$options = [
			1 => 'Fall',
			2 => 'Spring',
			3 => 'Summer',
		];

		$mform->addElement('html', '<tr><td class="mycell2">Choose the current school Term</td><td>');
		$select = $mform->addElement('select', 'schoolterm', '', $options);
		$select->setSelected($defaultterm);
		$mform->addElement('html', '</td></tr>');

		/**
		 * Choose the Advisory Teacher
		 */
		$advisors = mod_istudymasterschedule\utils::get_advisors();
		$default_advisor = mod_istudymasterschedule\utils::get_default_advisor($advisors);
		$mform->addElement('html', '<tr><td class="mycell2">Choose All Advisors or a Specific Advisor</td><td>');
		$select = $mform->addElement('select', 'advisor', '', $advisors);
		$select->setSelected($default_advisor);
		$mform->addElement('html', '</td></tr>');

		/**
		 * Include course with student name (Yes or No)?
		 */
		$mform->addElement('html', '<tr><td class="mycell2">Include course with student name?</td><td>');
		$mform->addElement('selectyesno', 'yes_or_no', '');
		$mform->setDefault('yes_or_no', 1);
		$mform->addElement('html', '</td></tr>');

		$mform->addElement('html', '</table><br>');

		$mform->addElement('hidden', 'cmid');
        $mform->setType('cmid', PARAM_INT);
		$mform->addElement('hidden', 'id');
        $mform->setType('id', PARAM_INT);
		$mform->addElement('html', '<br><h3>  </h3>');

		/**
		 * Add standard buttons that iscommon to all modules.
		 */
		$mform->addElement('html', '<div class="buttonsetup">');
		$this->add_action_buttons($cancel = true, $submitlabel='Submit');
		$mform->addElement('html', '</div>');
    }
}