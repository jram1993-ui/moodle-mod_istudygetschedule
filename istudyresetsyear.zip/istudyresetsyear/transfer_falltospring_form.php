<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * The main istudy configuration form used for entering attendance credit
 *
 * It uses the standard core Moodle formslib. For more info about them, please
 * visit: http://docs.moodle.org/en/Development:lib/formslib.php
 *
 * @package    mod_istudy
 * @copyright  2024 Jesus Ramirez <jram1993@gmail.com>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

require_once($CFG->dirroot.'/lib/formslib.php');

/**
 * Module instance settings form
 *
 * @package    mod_istudyresetsyear
 * @copyright  2024 Jesus Ramirez <jram1993@gmail.com>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class mod_istudyresetsyear_transfer_falltospring_form extends \moodleform
{
    public function definition()
	{
        $mform    = $this->_form;

		$mform->addElement('html', '<link rel="stylesheet" type="text/css" href="styles-transfer_falltospring.css"><div class="mydiv">');
		$mform->addElement('html', '<h3>Transfer before Start of Spring Semester</h3>');
		$mform->addElement('html', '<h4>Fall to Spring Semesters</h4><br>');

		$mform->addElement('html', '<br><h5>Transfer fall courses and credits to the spring...</h5><br>');
		$mform->addElement('textarea', 'transferconfirmation', 'Type TRANSFER to comfirm', 'wrap="virtual" rows="1" cols="60"');
		$mform->setDefault('transferconfirmation', '');
		$mform->setType('transferconfirmation', PARAM_TEXT);

		// Hidden id number for sending the data back.
		$mform->addElement('hidden', 'id');
        $mform->setType('id', PARAM_INT);

		// Add standard buttons, common to all modules.
		$mform->addElement('html', '<br><h3>  </h3>');
        $this->add_action_buttons(true, 'TRANSFER Fall to Spring');
		$mform->addElement('html', '</div>');
	}
}