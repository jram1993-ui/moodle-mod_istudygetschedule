<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * @package    mod_istudyprintattendanc
 * @copyright  2024 Jesus Ramirez <jram1993@gmail.com>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace mod_istudyprintattendanc;

use stdClass;

/**
 * Class student_info
 *
 * @package    mod_istudyprintattendanc
 * @copyright  2024 Jesus Ramirez <jram1993@gmail.com>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class student_info {

	// Get a list of students using the search criteria.
	public static function get_studentlist($advisorlist, $lastnamesearch, $enrollment_status) {
		global $DB;
		$table = '{' . 'user' . '}';
		$select = " lastname LIKE " . "'" . $lastnamesearch . "'";
		$params = null;
		$sort =" ORDER BY lastname ASC, firstname ASC";
		$fields='id, firstname, lastname, email, deleted, suspended';
		$sql = "SELECT " . $fields . " FROM " . $table . " WHERE " . $select . $sort;
		$mystudent_lists = $DB->get_records_sql($sql, $params, 0, 0);
		$count = 0;
		$students_were_found = false;
		// Search for active students only.
		if ($enrollment_status == 1) {
			foreach ($mystudent_lists as $mystudent_list) {
				$record_found = true;
				$student_id = $mystudent_list->id;
				// Check for admin user, guest user, and anon user. If found, skip.
				if (($mystudent_list->firstname == 'Admin') OR (substr($mystudent_list->firstname, 0, 4) == 'anon')
					OR (substr($mystudent_list->firstname, 0, 5) == 'Guest') OR ($mystudent_list->deleted) OR ($mystudent_list->suspended)){
					$record_found = false;
				}
				// Get the year and term according to the search criteria.
				if ($record_found == true) {
					$whichuser_status = utils::get_field_data($student_id, utils::get_fieldid('whichteacher'));
					$myadvisor = utils::get_field_data($student_id, utils::get_fieldid('advisor'));
					// Check to see if user is an advisor or parent.  If so, exclude user.
					if ($whichuser_status <> 'Student') {
							$record_found = false; }
					// Check to see if the all adivsors or single advisor chosen match up.
					else if ($advisorlist <> 'All' AND $advisorlist <> $myadvisor) {
						$record_found = false;
					}
				}
				if ($record_found == true) {
					$students_were_found = true;
					$count = $count +1;
					$students_found[$count] = new stdClass();
					// Student id, last name, & first name.
					$students_found[$count]->id = $student_id;
					$students_found[$count]->schoolid = utils::get_field_data($student_id, utils::get_fieldid('schoolid'));
					$students_found[$count]->email = $mystudent_list->email;
					$students_found[$count]->lastname = $mystudent_list->lastname;
					$students_found[$count]->firstname = $mystudent_list->firstname;
					// Student grade level.
					$my_gradelevel = utils::get_gradelevel(utils::get_field_data($student_id, utils::get_fieldid('graduationyear')));
					$students_found[$count]->gradelevel = $my_gradelevel;
					// Student's advisor
					$my_advisor = utils::get_field_data($student_id, utils::get_fieldid('advisor'));
					$students_found[$count]->advisor = $my_advisor;
					// Student's date of birth
					$students_found[$count]->birthdate = utils::get_field_data($student_id, utils::get_fieldid('dob'));
					// Student's grade point average
					$students_found[$count]->gpa = utils::get_field_data($student_id, utils::get_fieldid('gpa'));
					// Student's enrollment date
					$students_found[$count]->startdate = utils::get_field_data($student_id, utils::get_fieldid('startdate'));
				}
			}
		}
		// Search for inactive students only - they are no longer enrolled at the school
		else {

			foreach ($mystudent_lists as $mystudent_list) {
				$record_found = true;
				$student_id = $mystudent_list->id;
				// Check for admin user, guest user, and anon user. If found, skip.
				if (($mystudent_list->firstname == 'Admin') OR (substr($mystudent_list->firstname, 0, 4) == 'anon')
					OR (substr($mystudent_list->firstname, 0, 5) == 'Guest') OR ($mystudent_list->deleted) OR !($mystudent_list->suspended)){
					$record_found = false; }
				// Get the year and term according to the search criteria.
				if ($record_found == true) {
					$myadvisor = utils::get_field_data($student_id, utils::get_fieldid('advisor'));
					// Check to see if user is an advisor.  If so, exclude user.
					if ($myadvisor == 'Advisor') {
							$record_found = false; }
					// Check to see if the all adivsors or single advisor chosen match up.
					else if ($advisorlist <> 'All' AND $advisorlist <> $myadvisor) {
						$record_found = false;
					}
				}
				if ($record_found == true) {
					$students_were_found = true;
					$count = $count +1;
					$students_found[$count] = new stdClass();
					// Student id, last name, & first name.
					$students_found[$count]->id = $student_id;
					$students_found[$count]->schoolid = utils::get_field_data($student_id, utils::get_fieldid('schoolid'));
					$students_found[$count]->email = $mystudent_list->email;
					$students_found[$count]->lastname = $mystudent_list->lastname;
					$students_found[$count]->firstname = $mystudent_list->firstname;
					// Student grade level
					$my_gradelevel = utils::get_gradelevel(utils::get_field_data($student_id, utils::get_fieldid('graduationyear')));
					$students_found[$count]->gradelevel = $my_gradelevel;
					// Student's advisor
					$my_advisor = utils::get_field_data($student_id, utils::get_fieldid('advisor'));
					$students_found[$count]->advisor = $my_advisor;
					// Student's date of birth
					$students_found[$count]->birthdate = utils::get_field_data($student_id, utils::get_fieldid('dob'));
					// Student's grade point average
					$students_found[$count]->gpa = utils::get_field_data($student_id, utils::get_fieldid('gpa'));
					// Student's enrollment date
					$students_found[$count]->startdate = utils::get_field_data($student_id, utils::get_fieldid('startdate'));
				}
			}
		}
		if ($students_were_found == false){
			return NULL; }
		else {
			return $students_found;  }
	}

	// Get single student record.
	public static function get_singlestudent($student_id) {
		global $DB;
		// Student Info
		$student_info = new stdClass();
		$student_info->id = $student_id;
		$student_temp = $DB->get_record('user', ['id' => $student_id] , '*');
		$student_info->lastname = $student_temp->lastname;
		$student_info->firstname = $student_temp->firstname;
		$student_info->schoolid = utils::get_field_data($student_id, utils::get_fieldid('schoolid'));
		$student_info->creditsearned = utils::get_field_data($student_id, utils::get_fieldid('creditsearned'));
		$student_info->creditsneeded = utils::get_field_data($student_id, utils::get_fieldid('creditsneeded'));
		$student_info->gradelevel = utils::get_gradelevel(utils::get_field_data($student_id, utils::get_fieldid('graduationyear')));
		$my_advisor = utils::get_field_data($student_id, utils::get_fieldid('advisor'));
		$student_info->advisor = $my_advisor;
		return $student_info;
	}

	// Get the student demographics.
	public static function get_individual_info($student_id) {
		global $DB;
		// Student Info
		$student_info = new stdClass();
		$student_info->id = $student_id;
		$student_info->school_id = utils::get_field_data($student_id, utils::get_fieldid('schoolid'));
		$student_temp = $DB->get_record('user', ['id' => $student_id] , 'firstname, lastname, deleted, suspended');
		$student_info->student_name = $student_temp->lastname . ', ' . $student_temp->firstname;
		$student_info->deleted = $student_temp->deleted;
		$student_info->suspended = $student_temp->suspended;
		$student_info->grade = utils::get_gradelevel(utils::get_field_data($student_id, utils::get_fieldid('graduationyear')));
		$temp_startdate = utils::get_field_data($student_id, utils::get_fieldid('startdate'));
		if (intval($temp_startdate) > 0) {
			$student_info->startdate = date("m-d-y", $temp_startdate);
		}
		else {
			$student_info->startdate = '';
		}
		$my_advisor = utils::get_field_data($student_id, utils::get_fieldid('advisor'));
		$student_info->advisor = utils::put_comma_in_name($my_advisor);
		return $student_info;
	}

	// Get a single student card ready.
	public static function get_studentcard($student_id, $school_month, $month_info) {
		global $DB;
		$week1_count = new stdClass();
		$week2_count = new stdClass();
		$week3_count = new stdClass();
		$week4_count = new stdClass();

		//Title for the individual card
		$student_card = '<link rel="stylesheet" type="text/css" href="styles-student_card.css"><html><head><title>Attendance Cards</title></head><body><h1>' .
			get_config('mod_istudy', 'schoolname') . '</h1><h2>Assignment/Completion Record</h2>';
		$student_info = student_info::get_singlestudent($student_id);
		$student_card = $student_card . '<table><tr><col width="10%"><col width="35%"><col width="20%"><col width="35%">' .
			'<th class="bottomborder_light"><b>Name:</b></th><td class="leftrightborder_dark">' . $student_info->lastname . ', ' . $student_info->firstname .
			'</td><th class="bottomborder_light"><b>Advisory Teacher:</b></th><td class="leftborder_dark_only">' . utils::put_comma_in_name($student_info->advisor) . '</td></tr>';
		$student_card = $student_card . '<tr><th align="right" class="bottomborder_light"><b>ID#</b></th><td align="left" class="leftrightborder_dark">' .
			$student_info->schoolid . '</td><th align="right"><b>Credits Completed:</b></th><td align="left" class="leftborder_dark_only">' .
			$student_info->creditsearned . '</td></tr>';
		$student_card = $student_card . '<tr><th align="right"><b>Grade:</b></th><td align="left" class="leftrightborder_dark">' . $student_info->gradelevel .
			'</td><th align="right" class="bottomborder_light"><b>Credits Needed:</b></th><td align="left" class="leftborder_dark_only">' .
			$student_info->creditsneeded . '</td></tr>';
		$student_card = $student_card . '<tr><th class="lefttopborder_dark">Notes:</th><td colspan="3" class="lefttopborder_dark"></td></tr></table>';
		$student_card = $student_card . '<h3>Month ' . $school_month . '</h3>';
		//Get the monthly attendance.
		$student_card = $student_card . '<table><tr><col width="2%"><col width="15%"><col width="15%"><col width="17%"><col width="17%"><col width="17%"><col width="17%">' .
			'<th>#</th><th><b>COURSES</b></th><th class="rightborder_dark_only">Resources Used</th><th>Week 1 - '  . $month_info->week01date . ' (' . $month_info->week01points . ')</th>' .
			'<th>Week 2 - '  . $month_info->week02date . ' (' . $month_info->week02points . ')</th>' .
			'<th>Week 3 - '  . $month_info->week03date . ' (' . $month_info->week03points . ')</th>' .
			'<th>Week 4 - '  . $month_info->week04date . ' (' . $month_info->week04points . ')</th></tr>';
		// Search database for courses with studentid, current month, and within this school year.
		$table = '{' . 'istudy_monthatten' . '}';
		$select = " student_id = " . $student_id . " AND month = " . $school_month;
		$params = null;
		$sort ="";
		$fields='*';
		$sql = "SELECT " . $fields . " FROM " . $table . " WHERE " . $select . $sort;
		$mystudent_lists = $DB->get_records_sql($sql, $params, 0, 0);
		// Add student courses to card.
		$count = 0;
		$week1_count = 0;
		$week2_count = 0;
		$week3_count = 0;
		$week4_count = 0;
		$course_count = -1;
		// Create a list of the courses - include attendance information.
		foreach ($mystudent_lists as $mystudent_list) {
			$count = $count + 1;
			$this_course[$count] = new stdClass();
			$this_course[$count]->coursename = utils::remove_extra_symbols(trim(utils::get_course_name($mystudent_list->course)));
			$this_course[$count]->teachername = utils::remove_extra_symbols(trim(teacher_info::get_teachername($mystudent_list->teacher_id)));
			$this_course[$count]->resources = utils::remove_extra_symbols(trim($mystudent_list->resources));
			// Get the description of each assignment for each week.
			$this_course[$count]->assignmentweek1 = utils::remove_extra_symbols(trim($mystudent_list->assignmentweek1));
			$this_course[$count]->assignmentweek2 = utils::remove_extra_symbols(trim($mystudent_list->assignmentweek2));
			$this_course[$count]->assignmentweek3 = utils::remove_extra_symbols(trim($mystudent_list->assignmentweek3));
			$this_course[$count]->assignmentweek4 = utils::remove_extra_symbols(trim($mystudent_list->assignmentweek4));
			// Get the synchronous (seat time) time for each student.
			$temp_sychronous_time1 = utils::get_synchronous_time($mystudent_list->student_id, $mystudent_list->teacher_id, $mystudent_list->course, $month_info->week01date);
			$temp_sychronous_time2 = utils::get_synchronous_time($mystudent_list->student_id, $mystudent_list->teacher_id, $mystudent_list->course, $month_info->week02date);
			$temp_sychronous_time3 = utils::get_synchronous_time($mystudent_list->student_id, $mystudent_list->teacher_id, $mystudent_list->course, $month_info->week03date);
			$temp_sychronous_time4 = utils::get_synchronous_time($mystudent_list->student_id, $mystudent_list->teacher_id, $mystudent_list->course, $month_info->week04date);
			// Get the total of hours for assignments turned in and hours for synchronous time.
			$temp_total_time1 = $mystudent_list->creditsweek1 + $temp_sychronous_time1;
			$temp_total_time2 = $mystudent_list->creditsweek2 + $temp_sychronous_time2;
			$temp_total_time3 = $mystudent_list->creditsweek3 + $temp_sychronous_time3;
			$temp_total_time4 = $mystudent_list->creditsweek4 + $temp_sychronous_time4;
			$this_course[$count]->creditsweek1_text = '<div class="attendance_points_total">' . $temp_total_time1 . '</div><div class="attendance_points">' . ($mystudent_list->creditsweek1+0) . '(W) + ' . $temp_sychronous_time1 . '(S)</div>';
			$this_course[$count]->creditsweek2_text = '<div class="attendance_points_total">' . $temp_total_time2 . '</div><div class="attendance_points">' . ($mystudent_list->creditsweek2+0) . '(W) + ' . $temp_sychronous_time2 . '(S)</div>';
			$this_course[$count]->creditsweek3_text = '<div class="attendance_points_total">' . $temp_total_time3 . '</div><div class="attendance_points">' . ($mystudent_list->creditsweek3+0) . '(W) + ' . $temp_sychronous_time3 . '(S)</div>';
			$this_course[$count]->creditsweek4_text = '<div class="attendance_points_total">' . $temp_total_time4 . '</div><div class="attendance_points">' . ($mystudent_list->creditsweek4+0) . '(W) + ' . $temp_sychronous_time4 . '(S)</div>';
			$this_course[$count]->creditsweek1 = $temp_total_time1;
			$this_course[$count]->creditsweek2 = $temp_total_time2;
			$this_course[$count]->creditsweek3 = $temp_total_time3;
			$this_course[$count]->creditsweek4 = $temp_total_time4;
		}
		// Sort by course name.
		$val = new stdClass();
		for ($i=1; $i<=$count; $i++){
			$val = $this_course[$i];
			$j = $i-1;
			while($j>=1 && $this_course[$j]->coursename > $val->coursename){
				$this_course[$j+1] = $this_course[$j];
				$j--;
			}
			$this_course[$j+1] = $val;
		}
		// Creat the attendance card - attendance work and credit for each course.
		for ($course_count=1; $course_count<=$count; $course_count++){
			// Get the course name and the assignments for weeks 1 through 4.
			$student_card = $student_card . '<tr valign="top" class="topborder_dark_only"><td rowspan="2" class="count_courses_cell">' . $course_count .
				'</td><td class="course_cell"><div class="course_week_col">' . $this_course[$course_count]->coursename . '</div></td>' .
				'<td rowspan="2" valign="top" class="rightborder_dark_only"><div class="resource_col">'. $this_course[$course_count]->resources . '</div></td>' .
				'<td class="week_assignment" valign="top"><div class="course_week_col">' . $this_course[$course_count]->assignmentweek1 . '</div><br /></td>' .
				'<td class="week_assignment" valign="top"><div class="course_week_col">' . $this_course[$course_count]->assignmentweek2 . '</div><br /></td>' .
				'<td class="week_assignment" valign="top"><div class="course_week_col">' . $this_course[$course_count]->assignmentweek3 . '</div><br /></td>' .
				'<td class="week_assignment" valign="top"><div class="course_week_col">' . $this_course[$course_count]->assignmentweek4 . '</div><br /></td></tr>';
			// Get the teacher name and the work credit for each week ( 1 = C, 2 = CC, 3 = CCC, 4 = CCCC, and 5 = CCCCC).
			$week1_count = $week1_count + $this_course[$course_count]->creditsweek1;
			$week2_count = $week2_count + $this_course[$course_count]->creditsweek2;
			$week3_count = $week3_count + $this_course[$course_count]->creditsweek3;
			$week4_count = $week4_count + $this_course[$course_count]->creditsweek4;

			$student_card = $student_card . '<tr><td class="advisor_cell">' . $this_course[$course_count]->teachername . '</td>' .
				'<td class="attendance_points_cell">' . $this_course[$course_count]->creditsweek1_text . '</td>' .
				'<td class="attendance_points_cell">' . $this_course[$course_count]->creditsweek2_text . '</td>' .
				'<td class="attendance_points_cell">' . $this_course[$course_count]->creditsweek3_text . '</td>' .
				'<td class="attendance_points_cell">' . $this_course[$course_count]->creditsweek4_text . '</td></tr>';
		}
		// Make adjustments to the total points if they have gone over, round a 3 to a 4, or round a 4 to a 5.
		$week1_count = utils::get_weekpoints($week1_count, $month_info->week01points);
		$week2_count = utils::get_weekpoints($week2_count, $month_info->week02points);
		$week3_count = utils::get_weekpoints($week3_count, $month_info->week03points);
		$week4_count = utils::get_weekpoints($week4_count, $month_info->week04points);
		$student_card = $student_card . '<tr><td class="rightborder_white"></td><td class="totals_cell_top_right" colspan="2">Total Attendance - Hours</td>' .
			'<td class="totals_hours">' . $week1_count->hours . '</td>' .
			'<td class="totals_hours">' . $week2_count->hours . '</td>' .
			'<td class="totals_hours">' . $week3_count->hours . '</td>'.
			'<td class="totals_hours">' . $week4_count->hours . '</td></tr>';
		$student_card = $student_card . '<tr><td class="rightborder_gray"></td><td class="totals_cell_right" colspan="2">Total Attendance - Days</td>' .
			'<td class="totals_days">' . $week1_count->days . '</td>' .
			'<td class="totals_days">' . $week2_count->days . '</td>' .
			'<td class="totals_days">' . $week3_count->days . '</td>'.
			'<td class="totals_days">' . $week4_count->days . '</td></tr>';
		$student_card = $student_card . '</table><h2>W = Hours for work completed, S = Synchronous time worked</h2></body></html>';
		// Add monthly attendance to the card.
		return $student_card;
	}

	// Make sure that at least 1 student was chosen.
	public static function get_student_chosen($submission) {
		$student_count = $submission->studentcount;
		for ($i = 1; $i <= $student_count; $i++) {
			$this_student = 'student_chosen' . $i;
            // Check to make sure that the student exists and has not been deleted (rare occurance).
            if (!property_exists($submission, $this_student)) {
                return false;
            }
            $this_studentid = $submission->$this_student;
            if ($this_studentid > 0) {
                return true;
            }
		}
		// No students were chosen.
		return false;
	}


	// If $hours_this_week is equal to 4 or more, return a checkmark.
	public static function checkbox_4hours_or_more($hours_this_week) {
		$hours_minimum_day = 4;
		if ($hours_this_week >= $hours_minimum_day) {
			return '<span class="checkbox_color">&#x2714</span>';
		}
		else if ($hours_this_week == 0) {
			return '<span class="emptybox_color">0</span>';
			// return '&#9744';
		}
		if ($hours_this_week == 1 OR $hours_this_week == 2 OR $hours_this_week == 3) {
			return '<span class="number_color">' . $hours_this_week . '</span>';
		}
		else {
			return '<span class="decimal_color">' . intval($hours_this_week) . '</span>';
		}
	}

	// Get a single student and courses ready - output in 2 rows of 4 for a total of 8 classes.
	public static function get_attendancesummary($student_id, $school_month, $month_info, $student_count) {
		global $DB;

		// Search database for courses with studentid, current month, and within this school year.
		$table = '{' . 'istudy_monthatten' . '}';
		$select = " student_id = " . $student_id . " AND month = " . $school_month;
		$params = null;
		$sort ="";
		$fields='*';
		// Count the number of lines used for this student on the page (default is 3).
		$rows_used = 3;

		$sql = "SELECT " . $fields . " FROM " . $table . " WHERE " . $select . $sort;
		$mystudent_lists = $DB->get_records_sql($sql, $params, 0, 0);

		// Add student courses to card.
		$count = 0;
		$total_hours_week1 = 0;
		$total_hours_week2 = 0;
		$total_hours_week3 = 0;
		$total_hours_week4 = 0;
		$student_info = student_info::get_singlestudent($student_id);
		// Initialize the course list.
		for ($i = 1; $i <= 16; $i++) {
			$name_of_course[$i] = '';
			$course_points[$i] = '';
			$student_course[$i] = new stdClass();
			$student_course[$i]->teacher_id = 0;
			$student_course[$i]->course_id = 0;
			$student_course[$i]->course_name = '';
			$student_course[$i]->week1_credits = '';
			$student_course[$i]->week2_credits = '';
			$student_course[$i]->week3_credits = '';
			$student_course[$i]->week4_credits = '';
		}
		foreach ($mystudent_lists as $mystudent_list) {
			$count = $count + 1;
			$student_course[$count]->teacher_id = $mystudent_list->teacher_id;
			$student_course[$count]->course_id = $mystudent_list->course;
			$student_course[$count]->course_name = utils::get_course_name($mystudent_list->course);
			$student_course[$count]->week1_credits = $mystudent_list->creditsweek1;
			$student_course[$count]->week2_credits = $mystudent_list->creditsweek2;
			$student_course[$count]->week3_credits = $mystudent_list->creditsweek3;
			$student_course[$count]->week4_credits = $mystudent_list->creditsweek4;
		}
		// Sort by course name.
		$val = new stdClass();
		for ($i=1; $i<=$count; $i++){
			$val = $student_course[$i];
			$j = $i-1;
			while($j>=1 && $student_course[$j]->course_name > $val->course_name){
				$student_course[$j+1] = $student_course[$j];
				$j--;
			}
			$student_course[$j+1] = $val;
		}
		// If the student has 10 courses or less, then print studnent courses using only 2 rows with 5 classes in each row.
		if ($count <= 8) {
			$mystudent_info = '<tr><td rowspan="3"><center><b>' . $student_count . '</b></center></td><td  class = "student_last_name"><b>' . $student_info->lastname . ',</b></td>';
			for ($i = 1; $i <= 4; $i++) {
				if ($i <= $count) {
					// Get the synchronous (seat time) time for each student.
					$temp_sychronous_time1 = utils::get_synchronous_time($student_id, $student_course[$i]->teacher_id, $student_course[$i]->course_id, $month_info->week01date);
					$temp_sychronous_time2 = utils::get_synchronous_time($student_id, $student_course[$i]->teacher_id, $student_course[$i]->course_id, $month_info->week02date);
					$temp_sychronous_time3 = utils::get_synchronous_time($student_id, $student_course[$i]->teacher_id, $student_course[$i]->course_id, $month_info->week03date);
					$temp_sychronous_time4 = utils::get_synchronous_time($student_id, $student_course[$i]->teacher_id, $student_course[$i]->course_id, $month_info->week04date);
					// Get the total of hours for assignments turned in and hours for synchronous time.
					$temp_total_time1 = floatval($student_course[$i]->week1_credits) + $temp_sychronous_time1;
					$temp_total_time2 = floatval($student_course[$i]->week2_credits) + $temp_sychronous_time2;
					$temp_total_time3 = floatval($student_course[$i]->week3_credits) + $temp_sychronous_time3;
					$temp_total_time4 = floatval($student_course[$i]->week4_credits) + $temp_sychronous_time4;
					// Add the hours to the weekly total.
					$total_hours_week1 = $total_hours_week1 + $temp_total_time1;
					$total_hours_week2 = $total_hours_week2 + $temp_total_time2;
					$total_hours_week3 = $total_hours_week3 + $temp_total_time3;
					$total_hours_week4 = $total_hours_week4 + $temp_total_time4;
					// Print a checkmark if hours work this course (this week) is 4 hours or more.
					$course_points =  student_info::checkbox_4hours_or_more($temp_total_time1) . student_info::checkbox_4hours_or_more($temp_total_time2) .
						student_info::checkbox_4hours_or_more($temp_total_time3) . student_info::checkbox_4hours_or_more($temp_total_time4);
					$mystudent_info = $mystudent_info . '<td class="course_cell_top">' . $student_course[$i]->course_name .
					'</td><td class="course_cell_top_points">' . $course_points . '</td>';
				}
				else {
					$mystudent_info = $mystudent_info . '<td class="course_cell_top"></td><td class="course_cell_top_points"></td>';
				}
			}
			$mystudent_info = $mystudent_info . '</tr>';
			// Set up the second row for this student - if numberofsessions < 6, print second row with first name and empty cells.
			$mystudent_info = $mystudent_info . '<tr><td class = "student_first_name"><b>' . $student_info->firstname . ' (' . $student_info->gradelevel . ')</b></td>';
			for ($i = 5; $i <= 8; $i++) {
				if ($i <= $count) {
					// Get the synchronous (seat time) time for each student.
					$temp_sychronous_time1 = utils::get_synchronous_time($student_id, $student_course[$i]->teacher_id, $student_course[$i]->course_id, $month_info->week01date);
					$temp_sychronous_time2 = utils::get_synchronous_time($student_id, $student_course[$i]->teacher_id, $student_course[$i]->course_id, $month_info->week02date);
					$temp_sychronous_time3 = utils::get_synchronous_time($student_id, $student_course[$i]->teacher_id, $student_course[$i]->course_id, $month_info->week03date);
					$temp_sychronous_time4 = utils::get_synchronous_time($student_id, $student_course[$i]->teacher_id, $student_course[$i]->course_id, $month_info->week04date);
					// Get the total of hours for assignments turned in and hours for synchronous time.
					$temp_total_time1 = floatval($student_course[$i]->week1_credits) + $temp_sychronous_time1;
					$temp_total_time2 = floatval($student_course[$i]->week2_credits) + $temp_sychronous_time2;
					$temp_total_time3 = floatval($student_course[$i]->week3_credits) + $temp_sychronous_time3;
					$temp_total_time4 = floatval($student_course[$i]->week4_credits) + $temp_sychronous_time4;
					// Add the hours to the weekly total.
					$total_hours_week1 = $total_hours_week1 + $temp_total_time1;
					$total_hours_week2 = $total_hours_week2 + $temp_total_time2;
					$total_hours_week3 = $total_hours_week3 + $temp_total_time3;
					$total_hours_week4 = $total_hours_week4 + $temp_total_time4;
					// Print a checkmark if hours work this course (this week) is 4 hours or more.
					$course_points =  student_info::checkbox_4hours_or_more($temp_total_time1) . student_info::checkbox_4hours_or_more($temp_total_time2) .
					student_info::checkbox_4hours_or_more($temp_total_time3) . student_info::checkbox_4hours_or_more($temp_total_time4);

					$mystudent_info = $mystudent_info . '<td  class="course_cell_bottom">' . $student_course[$i]->course_name .
						'</td><td class="course_cell_bottom_points">' . $course_points . '</td>';
				}
				else {
					$mystudent_info = $mystudent_info . '<td  class="course_cell_bottom"></td><td class="course_cell_bottom_points"></td>';
				}
			}
			$mystudent_info = $mystudent_info . '</tr>';
		}
		// The student has more than 8 courses but less than 12. Print 3 rows to allow for a total of 12 classes.
		else if ($count <= 12){
			$rows_used = 4;
			$mystudent_info = '<tr><td rowspan="4"><center><b>' . $student_count . '</b></center></td><td  class = "student_last_name"><b>' . $student_info->lastname . '</b></td>';
			for ($i = 1; $i <= 4; $i++) {
				if ($i <= $count) {
					// Get the synchronous (seat time) time for each student.
					$temp_sychronous_time1 = utils::get_synchronous_time($student_id, $student_course[$i]->teacher_id, $student_course[$i]->course_id, $month_info->week01date);
					$temp_sychronous_time2 = utils::get_synchronous_time($student_id, $student_course[$i]->teacher_id, $student_course[$i]->course_id, $month_info->week02date);
					$temp_sychronous_time3 = utils::get_synchronous_time($student_id, $student_course[$i]->teacher_id, $student_course[$i]->course_id, $month_info->week03date);
					$temp_sychronous_time4 = utils::get_synchronous_time($student_id, $student_course[$i]->teacher_id, $student_course[$i]->course_id, $month_info->week04date);
					// Get the total of hours for assignments turned in and hours for synchronous time.
					$temp_total_time1 = floatval($student_course[$i]->week1_credits) + $temp_sychronous_time1;
					$temp_total_time2 = floatval($student_course[$i]->week2_credits) + $temp_sychronous_time2;
					$temp_total_time3 = floatval($student_course[$i]->week3_credits) + $temp_sychronous_time3;
					$temp_total_time4 = floatval($student_course[$i]->week4_credits) + $temp_sychronous_time4;
					// Add the hours to the weekly total.
					$total_hours_week1 = $total_hours_week1 + $temp_total_time1;
					$total_hours_week2 = $total_hours_week2 + $temp_total_time2;
					$total_hours_week3 = $total_hours_week3 + $temp_total_time3;
					$total_hours_week4 = $total_hours_week4 + $temp_total_time4;
					// Print a checkmark if hours work this course (this week) is 4 hours or more.
					$course_points =  student_info::checkbox_4hours_or_more($temp_total_time1) . student_info::checkbox_4hours_or_more($temp_total_time2) .
					student_info::checkbox_4hours_or_more($temp_total_time3) . student_info::checkbox_4hours_or_more($temp_total_time4);

					$mystudent_info = $mystudent_info . '<td class="course_cell_top">' . $student_course[$i]->course_name .
					'</td><td class="course_cell_top_points">' . $course_points . '</td>';
				}
				else {
					$mystudent_info = $mystudent_info . '<td class="course_cell_top"></td><td class="course_cell_top_points"></td>';
				}
			}
			$mystudent_info = $mystudent_info . '</tr>';
			// Set up the second row for this student.
			$mystudent_info = $mystudent_info . '<tr><td class = "student_first_name"><b>' . $student_info->firstname . ' (' . $student_info->gradelevel . ')</b></td>';
			for ($i = 5; $i <= 8; $i++) {
				if ($i <= $count) {
					// Get the synchronous (seat time) time for each student.
					$temp_sychronous_time1 = utils::get_synchronous_time($student_id, $student_course[$i]->teacher_id, $student_course[$i]->course_id, $month_info->week01date);
					$temp_sychronous_time2 = utils::get_synchronous_time($student_id, $student_course[$i]->teacher_id, $student_course[$i]->course_id, $month_info->week02date);
					$temp_sychronous_time3 = utils::get_synchronous_time($student_id, $student_course[$i]->teacher_id, $student_course[$i]->course_id, $month_info->week03date);
					$temp_sychronous_time4 = utils::get_synchronous_time($student_id, $student_course[$i]->teacher_id, $student_course[$i]->course_id, $month_info->week04date);
					// Get the total of hours for assignments turned in and hours for synchronous time.
					$temp_total_time1 = floatval($student_course[$i]->week1_credits) + $temp_sychronous_time1;
					$temp_total_time2 = floatval($student_course[$i]->week2_credits) + $temp_sychronous_time2;
					$temp_total_time3 = floatval($student_course[$i]->week3_credits) + $temp_sychronous_time3;
					$temp_total_time4 = floatval($student_course[$i]->week4_credits) + $temp_sychronous_time4;
					// Add the hours to the weekly total.
					$total_hours_week1 = $total_hours_week1 + $temp_total_time1;
					$total_hours_week2 = $total_hours_week2 + $temp_total_time2;
					$total_hours_week3 = $total_hours_week3 + $temp_total_time3;
					$total_hours_week4 = $total_hours_week4 + $temp_total_time4;
					// Print a checkmark if hours work this course (this week) is 4 hours or more.
					$course_points =  student_info::checkbox_4hours_or_more($temp_total_time1) . student_info::checkbox_4hours_or_more($temp_total_time2) .
					student_info::checkbox_4hours_or_more($temp_total_time3) . student_info::checkbox_4hours_or_more($temp_total_time4);
					$mystudent_info = $mystudent_info . '<td  class="course_cell_middle">' . $student_course[$i]->course_name .
						'</td><td class="course_cell_middle_points">' . $course_points . '</td>';
				}
				else {
					$mystudent_info = $mystudent_info . '<td  class="course_cell_middle"></td><td class="course_cell_middle_points"></td>';
				}
			}
			// Set up the third row for this student.
			$mystudent_info = $mystudent_info . '<tr><td class = "student_first_name"></td>';
			for ($i = 9; $i <= 12; $i++) {
				if ($i <= $count) {
					// Get the synchronous (seat time) time for each student.
					$temp_sychronous_time1 = utils::get_synchronous_time($student_id, $student_course[$i]->teacher_id, $student_course[$i]->course_id, $month_info->week01date);
					$temp_sychronous_time2 = utils::get_synchronous_time($student_id, $student_course[$i]->teacher_id, $student_course[$i]->course_id, $month_info->week02date);
					$temp_sychronous_time3 = utils::get_synchronous_time($student_id, $student_course[$i]->teacher_id, $student_course[$i]->course_id, $month_info->week03date);
					$temp_sychronous_time4 = utils::get_synchronous_time($student_id, $student_course[$i]->teacher_id, $student_course[$i]->course_id, $month_info->week04date);
					// Get the total of hours for assignments turned in and hours for synchronous time.
					$temp_total_time1 = floatval($student_course[$i]->week1_credits) + $temp_sychronous_time1;
					$temp_total_time2 = floatval($student_course[$i]->week2_credits) + $temp_sychronous_time2;
					$temp_total_time3 = floatval($student_course[$i]->week3_credits) + $temp_sychronous_time3;
					$temp_total_time4 = floatval($student_course[$i]->week4_credits) + $temp_sychronous_time4;
					// Add the hours to the weekly total.
					$total_hours_week1 = $total_hours_week1 + $temp_total_time1;
					$total_hours_week2 = $total_hours_week2 + $temp_total_time2;
					$total_hours_week3 = $total_hours_week3 + $temp_total_time3;
					$total_hours_week4 = $total_hours_week4 + $temp_total_time4;
					// Print a checkmark if hours work this course (this week) is 4 hours or more.
					$course_points = student_info::checkbox_4hours_or_more($temp_total_time1) . student_info::checkbox_4hours_or_more($temp_total_time2) .
					student_info::checkbox_4hours_or_more($temp_total_time3) . student_info::checkbox_4hours_or_more($temp_total_time4);

					$mystudent_info = $mystudent_info . '<td  class="course_cell_3rd_row">' . $student_course[$i]->course_name .
						'</td><td class="course_cell_3rd_row_points">' . $course_points . '</td>';
				}
				else {
					$mystudent_info = $mystudent_info . '<td  class="course_cell_3rd_row"></td><td class="course_cell_3rd_row_points"></td>';
				}
			}
			$mystudent_info = $mystudent_info . '</tr>';
		}
		// The student has more than 12 courses but less than 16. Print 4 rows to allow for a total of 16 classes.
		else {
			$rows_used = 5;
			$mystudent_info = '<tr><td rowspan="5"><center><b>' . $student_count . '</b></center></td><td  class = "student_last_name"><b>' . $student_info->lastname . '</b></td>';
			for ($i = 1; $i <= 4; $i++) {
				if ($i <= $count) {
					// Get the synchronous (seat time) time for each student.
					$temp_sychronous_time1 = utils::get_synchronous_time($student_id, $student_course[$i]->teacher_id, $student_course[$i]->course_id, $month_info->week01date);
					$temp_sychronous_time2 = utils::get_synchronous_time($student_id, $student_course[$i]->teacher_id, $student_course[$i]->course_id, $month_info->week02date);
					$temp_sychronous_time3 = utils::get_synchronous_time($student_id, $student_course[$i]->teacher_id, $student_course[$i]->course_id, $month_info->week03date);
					$temp_sychronous_time4 = utils::get_synchronous_time($student_id, $student_course[$i]->teacher_id, $student_course[$i]->course_id, $month_info->week04date);
					// Get the total of hours for assignments turned in and hours for synchronous time.
					$temp_total_time1 = floatval($student_course[$i]->week1_credits) + $temp_sychronous_time1;
					$temp_total_time2 = floatval($student_course[$i]->week2_credits) + $temp_sychronous_time2;
					$temp_total_time3 = floatval($student_course[$i]->week3_credits) + $temp_sychronous_time3;
					$temp_total_time4 = floatval($student_course[$i]->week4_credits) + $temp_sychronous_time4;
					// Add the hours to the weekly total.
					$total_hours_week1 = $total_hours_week1 + $temp_total_time1;
					$total_hours_week2 = $total_hours_week2 + $temp_total_time2;
					$total_hours_week3 = $total_hours_week3 + $temp_total_time3;
					$total_hours_week4 = $total_hours_week4 + $temp_total_time4;
					// Print a checkmark if hours work this course (this week) is 4 hours or more.
					$course_points =  student_info::checkbox_4hours_or_more($temp_total_time1) . student_info::checkbox_4hours_or_more($temp_total_time2) .
						student_info::checkbox_4hours_or_more($temp_total_time3) . student_info::checkbox_4hours_or_more($temp_total_time4);

					$mystudent_info = $mystudent_info . '<td class="course_cell_top">' . $student_course[$i]->course_name .
						'</td><td class="course_cell_top_points">' . $course_points . '</td>';
				}
				else {
					$mystudent_info = $mystudent_info . '<td class="course_cell_top"></td><td class="course_cell_top_points"></td>';
				}
			}
			$mystudent_info = $mystudent_info . '</tr>';
			// Set up the second row for this student.
			$mystudent_info = $mystudent_info . '<tr><td class = "student_first_name"><b>' . $student_info->firstname . ' (' . $student_info->gradelevel . ')</b></td>';
			for ($i = 5; $i <= 8; $i++) {
				if ($i <= $count) {
					// Get the synchronous (seat time) time for each student.
					$temp_sychronous_time1 = utils::get_synchronous_time($student_id, $student_course[$i]->teacher_id, $student_course[$i]->course_id, $month_info->week01date);
					$temp_sychronous_time2 = utils::get_synchronous_time($student_id, $student_course[$i]->teacher_id, $student_course[$i]->course_id, $month_info->week02date);
					$temp_sychronous_time3 = utils::get_synchronous_time($student_id, $student_course[$i]->teacher_id, $student_course[$i]->course_id, $month_info->week03date);
					$temp_sychronous_time4 = utils::get_synchronous_time($student_id, $student_course[$i]->teacher_id, $student_course[$i]->course_id, $month_info->week04date);
					// Get the total of hours for assignments turned in and hours for synchronous time.
					$temp_total_time1 = floatval($student_course[$i]->week1_credits) + $temp_sychronous_time1;
					$temp_total_time2 = floatval($student_course[$i]->week2_credits) + $temp_sychronous_time2;
					$temp_total_time3 = floatval($student_course[$i]->week3_credits) + $temp_sychronous_time3;
					$temp_total_time4 = floatval($student_course[$i]->week4_credits) + $temp_sychronous_time4;
					// Add the hours to the weekly total.
					$total_hours_week1 = $total_hours_week1 + $temp_total_time1;
					$total_hours_week2 = $total_hours_week2 + $temp_total_time2;
					$total_hours_week3 = $total_hours_week3 + $temp_total_time3;
					$total_hours_week4 = $total_hours_week4 + $temp_total_time4;
					// Print a checkmark if hours work this course (this week) is 4 hours or more.
					$course_points =  student_info::checkbox_4hours_or_more($temp_total_time1) . student_info::checkbox_4hours_or_more($temp_total_time2) .
						student_info::checkbox_4hours_or_more($temp_total_time3) . student_info::checkbox_4hours_or_more($temp_total_time4);

					$mystudent_info = $mystudent_info . '<td  class="course_cell_middle">' . $student_course[$i]->course_name .
						'</td><td class="course_cell_middle_points">' . $course_points . '</td>';
				}
				else {
					$mystudent_info = $mystudent_info . '<td  class="course_cell_middle"></td><td class="course_cell_middle_points"></td>';
				}
			}
			// Set up the third row for this student.
			$mystudent_info = $mystudent_info . '<tr><td class = "student_first_name"></td>';
			for ($i = 9; $i <= 12; $i++) {
				if ($i <= $count) {
					// Get the synchronous (seat time) time for each student.
					$temp_sychronous_time1 = utils::get_synchronous_time($student_id, $student_course[$i]->teacher_id, $student_course[$i]->course_id, $month_info->week01date);
					$temp_sychronous_time2 = utils::get_synchronous_time($student_id, $student_course[$i]->teacher_id, $student_course[$i]->course_id, $month_info->week02date);
					$temp_sychronous_time3 = utils::get_synchronous_time($student_id, $student_course[$i]->teacher_id, $student_course[$i]->course_id, $month_info->week03date);
					$temp_sychronous_time4 = utils::get_synchronous_time($student_id, $student_course[$i]->teacher_id, $student_course[$i]->course_id, $month_info->week04date);
					// Get the total of hours for assignments turned in and hours for synchronous time.
					$temp_total_time1 = floatval($student_course[$i]->week1_credits) + $temp_sychronous_time1;
					$temp_total_time2 = floatval($student_course[$i]->week2_credits) + $temp_sychronous_time2;
					$temp_total_time3 = floatval($student_course[$i]->week3_credits) + $temp_sychronous_time3;
					$temp_total_time4 = floatval($student_course[$i]->week4_credits) + $temp_sychronous_time4;
					// Add the hours to the weekly total.
					$total_hours_week1 = $total_hours_week1 + $temp_total_time1;
					$total_hours_week2 = $total_hours_week2 + $temp_total_time2;
					$total_hours_week3 = $total_hours_week3 + $temp_total_time3;
					$total_hours_week4 = $total_hours_week4 + $temp_total_time4;
					// Print a checkmark if hours work this course (this week) is 4 hours or more.
					$course_points =  student_info::checkbox_4hours_or_more($temp_total_time1) . student_info::checkbox_4hours_or_more($temp_total_time2) .
						student_info::checkbox_4hours_or_more($temp_total_time3) . student_info::checkbox_4hours_or_more($temp_total_time4);
					$mystudent_info = $mystudent_info . '<td  class="course_cell_3rd_row">' . $student_course[$i]->course_name .
						'</td><td class="course_cell_3rd_row_points">' . $course_points . '</td>';
				}
				else {
					$mystudent_info = $mystudent_info . '<td  class="course_cell_3rd_row"></td><td class="course_cell_3rd_row_points"></td>';
				}
			}
			// Set up the fourth row for this student.
			$mystudent_info = $mystudent_info . '<tr><td class = "student_first_name"><b>' . $student_info->firstname . ' (' . $student_info->gradelevel . ')</b></td>';
			for ($i = 13; $i <= 16; $i++) {
				if ($i <= $count) {
					// Get the synchronous (seat time) time for each student.
					$temp_sychronous_time1 = utils::get_synchronous_time($student_id, $student_course[$i]->teacher_id, $student_course[$i]->course_id, $month_info->week01date);
					$temp_sychronous_time2 = utils::get_synchronous_time($student_id, $student_course[$i]->teacher_id, $student_course[$i]->course_id, $month_info->week02date);
					$temp_sychronous_time3 = utils::get_synchronous_time($student_id, $student_course[$i]->teacher_id, $student_course[$i]->course_id, $month_info->week03date);
					$temp_sychronous_time4 = utils::get_synchronous_time($student_id, $student_course[$i]->teacher_id, $student_course[$i]->course_id, $month_info->week04date);
					// Get the total of hours for assignments turned in and hours for synchronous time.
					$temp_total_time1 = floatval($student_course[$i]->week1_credits) + $temp_sychronous_time1;
					$temp_total_time2 = floatval($student_course[$i]->week2_credits) + $temp_sychronous_time2;
					$temp_total_time3 = floatval($student_course[$i]->week3_credits) + $temp_sychronous_time3;
					$temp_total_time4 = floatval($student_course[$i]->week4_credits) + $temp_sychronous_time4;
					// Add the hours to the weekly total.
					$total_hours_week1 = $total_hours_week1 + $temp_total_time1;
					$total_hours_week2 = $total_hours_week2 + $temp_total_time2;
					$total_hours_week3 = $total_hours_week3 + $temp_total_time3;
					$total_hours_week4 = $total_hours_week4 + $temp_total_time4;
					// Print a checkmark if hours work this course (this week) is 4 hours or more.
					$course_points =  student_info::checkbox_4hours_or_more($temp_total_time1) . student_info::checkbox_4hours_or_more($temp_total_time2) .
						student_info::checkbox_4hours_or_more($temp_total_time3) . student_info::checkbox_4hours_or_more($temp_total_time4);
					$mystudent_info = $mystudent_info . '<td  class="course_cell_middle">' . $student_course[$i]->course_name .
						'</td><td class="course_cell_middle_points">' . $course_points . '</td>';
				}
				else {
					$mystudent_info = $mystudent_info . '<td  class="course_cell_middle"></td><td class="course_cell_middle_points"></td>';
				}
			}
			$mystudent_info = $mystudent_info . '</tr>';
		}
		// Print the total days and hours in the last row.
		$total_week1 = utils::get_weekpoints($total_hours_week1, $month_info->week01points);
		$total_week2 = utils::get_weekpoints($total_hours_week2, $month_info->week02points);
		$total_week3 = utils::get_weekpoints($total_hours_week3, $month_info->week03points);
		$total_week4 = utils::get_weekpoints($total_hours_week4, $month_info->week04points);
		$mystudent_info = $mystudent_info . '<tr><td  class="student_id">ID# ' . $student_info->schoolid . '</td>' .
			'<td  class="course_cell_total">WEEK 1</td><td class="course_cell_total_points">' . $total_week1->days . '</td>' .
			'<td  class="course_cell_total">WEEK 2</td><td class="course_cell_total_points">' . $total_week2->days . '</td>' .
			'<td  class="course_cell_total">WEEK 3</td><td class="course_cell_total_points">' . $total_week3->days . '</td>' .
			'<td  class="course_cell_total">WEEK 4</td><td class="course_cell_total_points">' . $total_week4->days . '</td></tr>';
		$temp_studentsummary = new stdClass();
		$temp_studentsummary->rows_used = $rows_used;
		$temp_studentsummary->mystudent_info = $mystudent_info;
		return $temp_studentsummary;
	}

	// Get the credits necesarry for the student and course.
	public static function get_course_credits($student_id, $course_id, $this_term, $number_of_sessions) {
		// Days of the week
		$week_day[1] = 'monday';
		$week_day[2] = 'tuesday';
		$week_day[3] = 'wednesday';
		$week_day[4] = 'thursday';
		$week_day[5] = 'friday';
		// Get the number of credits that the student needs for the course - only if the course is still part of the student schedule.
		for ($day_of_week = 1; $day_of_week <= 5; $day_of_week++) {
			for ($this_session = 1; $this_session <= $number_of_sessions; $this_session++){
				// Get the number of credits that the student needs for the course.
				$name_of_session = strtolower($this_term) . $week_day[$day_of_week] . 'session' . $this_session;
				$temp_get_courseid = utils::get_course_id(utils::get_field_data($student_id, utils::get_fieldid($name_of_session)));
				if ($temp_get_courseid <> 'None') {
					if ($temp_get_courseid == $course_id) {
						$name_of_session_credits = strtolower($this_term) . $week_day[$day_of_week] . 'creditssession' . $this_session;
						$temp_credits = utils::get_field_data($student_id, utils::get_fieldid($name_of_session_credits));
						// If the credits equal 0, keep looking.
						if ($temp_credits <> '0') {
							return $temp_credits;
						}
					}
				}
			}
		}
		return '0';
	}


	// Get a list of all of the student's current courses.
	public static function get_individual_course_info($student_id, $this_term) {
		global $DB;
		// Days of the week
		$week_day[1] = 'monday';
		$week_day[2] = 'tuesday';
		$week_day[3] = 'wednesday';
		$week_day[4] = 'thursday';
		$week_day[5] = 'friday';
		$number_of_sessions = get_config('mod_istudy', 'number_of_sessions');
		$count = 0;

		// Search database for courses with studentid, current month, and within this school year.
		$table = '{' . 'istudy_monthatten' . '}';
		// If fall term, look for months 1-5, else look for months 6-11.
		if (strtolower($this_term) == 'fall') {
			$select = " student_id = " . $student_id . " AND (month = 1 OR month = 2 OR month = 3 OR month = 4 OR month = 5)";
		}
		else {
			$select = " student_id = " . $student_id . " AND (month = 6 OR month = 7 OR month = 8 OR month = 9 OR month = 10 OR month = 11)";
		}
		$params = null;
		$sort = " ORDER BY course ASC";
		$fields='*';
		$sql = "SELECT " . $fields . " FROM " . $table . " WHERE " . $select . $sort;
		$student_courses = $DB->get_records_sql($sql, $params, 0, 0);
		$previous_course = "";
		foreach ($student_courses as $student_course) {
			// Check for a duplicate course.
			if ($student_course->course <> $previous_course) {
				$previous_course = $student_course->course;;
				$count = $count + 1;
				$student_info[$count] = new stdClass();
				$student_info[$count]->courseid = $student_course->course;
				$student_info[$count]->course_name = utils::get_course_name($student_course->course);
				$student_info[$count]->teacher = teacher_info::get_teachername($student_course->teacher_id);
				$student_info[$count]->teacherid = $student_course->teacher_id;
				// Check for course credits. If course have been dropped, give 0 credits.
				$student_info[$count]->credits = student_info::get_course_credits($student_id, $student_info[$count]->courseid, $this_term, $number_of_sessions);
			}
		}
		// Sort by course name.
		$val = new stdClass();
		for ($i=1; $i<=$count; $i++){
			$val = $student_info[$i];
			$j = $i-1;
			while($j>=1 && $student_info[$j]->course_name > $val->course_name){
				$student_info[$j+1] = $student_info[$j];
				$j--;
			}
			$student_info[$j+1] = $val;
		}
		$student_info[0] = new stdClass();
		$student_info[0]->count = $count;
		return $student_info;
	}

	// Create the page title for the top of the page - individual student work completion.
	public static function get_idividual_title($student_id, $school_term, $current_year) {
		$school_name =  get_config('mod_istudy', 'schoolname');
		$student_info = new stdClass();
		$student_info = student_info::get_singlestudent($student_id);
		// Initialize html page
		$page_title = '<link rel="stylesheet" type="text/css" href="styles-individual_report.css"><html><head><title>Attendance List</title></head><body>';
		// Page Title - School Information
		$page_title = $page_title . '<h1><u>' . $school_name . '</u></h1>' .
			'<h4>' . $student_info->lastname . ', ' . $student_info->firstname . ' (' . $student_info->gradelevel . ') - ID#' .
			$student_info->schoolid . '</h4>' .
			'<h3>' . strtoupper($school_term) .' '. $current_year . ' - Work Completion</h3>' .
			'<h2>Advisor - ' . utils::put_comma_in_name($student_info->advisor) . '</h2><br>';
		return $page_title;
	}

	// Create the header for the table - for individual student work completion.
	public static function get_individual_header($this_term) {
		// Set up titles for month collumn - Month 1, Month 2, etc.
		if ($this_term == 'Fall') {
			for ($i = 1; $i <= 5; $i++) {
				$title[$i] = 'Month ' . $i;
			}
			// The fall semester only has 5 months.
			$title[6] = '';
		}
		// Spring was chosen
		else {
			for ($i = 1; $i <= 6; $i++) {
				$title[$i] = 'Month ' . ($i + 5);
			}
		}
		$page_header = '<h1><u>Courses and Attendance Credit</u></h1><table>';
		$page_header = $page_header . '<tr class="maroon_background"><td width="2%" ><center>#</center></td>' .
			'<td width="22%" class="mycell"><center><b>Course</center></td><td width="16%"><center><b>Teacher</center></td>'.
			'<td width="10%" class="leftborder_dark_only" colspan="4"><center>' . $title[1] . '</center></td>' .
			'<td width="10%" class="leftborder_dark_only" colspan="4"><center>' . $title[2] . '</center></td>' .
			'<td width="10%" class="leftborder_dark_only" colspan="4"><center>' . $title[3] . '</center></td>' .
			'<td width="10%" class="leftborder_dark_only" colspan="4"><center>' . $title[4] . '</center></td>' .
			'<td width="10%" class="leftborder_dark_only" colspan="4"><center>' . $title[5] . '</center></td>' .
			'<td width="10%" class="leftborder_dark_only" colspan="4"><center>' . $title[6] . '</center></td>' .
			'</tr>';
		return $page_header;
	}

	// Create the header for the table - for individual student work completion.
	public static function get_individual_totals_header($this_term) {
		// Set up titles for month collumn - Month 1, Month 2, etc.
		if ($this_term == 'Fall') {
			for ($i = 1; $i <= 5; $i++) {
				$title[$i] = 'Month ' . $i;
			}
			// The fall semester only has 5 months.
			$title[6] = '';
		}
		// Spring was chosen.
		else {
			for ($i = 1; $i <= 6; $i++) {
				$title[$i] = 'Month ' . ($i + 5);
			}
		}
		$page_header = '<h1><u>Month Totals</u></h1><table>';
		$page_header = $page_header . '<tr class="fontfordates"><td width="40%" ><center><b>MONTH</b></center></td>'.
			'<td width="10%" class="leftborder_dark_only" colspan="4"><center>' . $title[1] . '</center></td>' .
			'<td width="10%" class="leftborder_dark_only" colspan="4"><center>' . $title[2] . '</center></td>' .
			'<td width="10%" class="leftborder_dark_only" colspan="4"><center>' . $title[3] . '</center></td>' .
			'<td width="10%" class="leftborder_dark_only" colspan="4"><center>' . $title[4] . '</center></td>' .
			'<td width="10%" class="leftborder_dark_only" colspan="4"><center>' . $title[5] . '</center></td>' .
			'<td width="10%" class="leftborder_dark_only" colspan="4"><center>' . $title[6] . '</center></td>' .
			'</tr>';
		return $page_header;
	}

	// If $hours_this_week is equal to 4 or more, return a checkmark.
	public static function four_hours_or_more($hours_this_week) {
		$hours_minimum_day = 4;
		if ($hours_this_week >= $hours_minimum_day) {
			return '&#10003';
		}
		else if ($hours_this_week == 0) {
			return '0';
		}
		else if ($hours_this_week == 1 OR $hours_this_week == 2 OR $hours_this_week == 3) {
			return $hours_this_week;
		}
		else {
			return '<span class="cell_decimal_color">' . $hours_this_week . '</span>';
		}
	}

	// Create the page title for the top of the page - individual student work completion.
	public static function get_courses_and_attendance($this_studentid, $this_term, $current_year, $points_possible, $week_dates, $month_info) {
		global $DB;
		$this_student_courses = student_info::get_individual_course_info($this_studentid, $this_term);
		$number_of_courses = $this_student_courses[0]->count;
		$attendance_card = student_info::get_idividual_title($this_studentid, $this_term, $current_year);
		$attendance_card = $attendance_card . student_info::get_individual_header($this_term);
		if ($this_term == 'Fall') {
			// Initialize count for the weekly totals.
			for ($init_month = 1; $init_month <= 5; $init_month++) {
				for ($init_week = 1; $init_week <= 4; $init_week++) {
					$week_total[$init_month][$init_week] = 0;
				}
			}
			// Print the student courses with the weeks attendance credit - Months 1-5.
			for ($course_count = 1; $course_count <= $number_of_courses; $course_count++) {
				$attendance_card = $attendance_card . '<tr><td>' . $course_count . '</td>' .
				'<td>' . $this_student_courses[$course_count]->course_name . ' [' . $this_student_courses[$course_count]->credits . ']</td>' .
				'<td>' . $this_student_courses [$course_count]->teacher . '</td>';
				for ($this_month = 1; $this_month <= 5; $this_month++) {
					$table = 'istudy_monthatten';
					$select = "student_id = :student_id AND teacher_id = :teacher_id AND course = :course AND month = :month";
					$params =['student_id'=>$this_studentid, 'teacher_id'=>$this_student_courses[$course_count]->teacherid, 'course'=>$this_student_courses[$course_count]->courseid, 'month'=>$this_month];
					if ($studentattendance = $DB->get_record_select($table, $select, $params)) {
						// Get the synchronous (seat time) time for each student.
						$temp_sychronous_time1 = utils::get_synchronous_time($this_studentid, $studentattendance->teacher_id, $studentattendance->course, $month_info[$this_month]->week01date);
						$temp_sychronous_time2 = utils::get_synchronous_time($this_studentid, $studentattendance->teacher_id, $studentattendance->course, $month_info[$this_month]->week02date);
						$temp_sychronous_time3 = utils::get_synchronous_time($this_studentid, $studentattendance->teacher_id, $studentattendance->course, $month_info[$this_month]->week03date);
						$temp_sychronous_time4 = utils::get_synchronous_time($this_studentid, $studentattendance->teacher_id, $studentattendance->course, $month_info[$this_month]->week04date);
						// Get the total of hours for assignments turned in and hours for synchronous time.
						$temp_total_time1 = $studentattendance->creditsweek1 + $temp_sychronous_time1;
						$temp_total_time2 = $studentattendance->creditsweek2 + $temp_sychronous_time2;
						$temp_total_time3 = $studentattendance->creditsweek3 + $temp_sychronous_time3;
						$temp_total_time4 = $studentattendance->creditsweek4 + $temp_sychronous_time4;
						// Print a checkmark if hours work this course (this week) is 4 hours or more.
						$attendance_card = $attendance_card . '<td class = "leftborder_dark_only"><center>' . student_info::four_hours_or_more($temp_total_time1) . '</center></td>';
						$attendance_card = $attendance_card . '<td><center>' . student_info::four_hours_or_more($temp_total_time2) . '</center></td>';
						$attendance_card = $attendance_card . '<td><center>' . student_info::four_hours_or_more($temp_total_time3) . '</center></td>';
						$attendance_card = $attendance_card . '<td><center>' . student_info::four_hours_or_more($temp_total_time4) . '</center></td>';
						// Add the hours to the total hours for all courses each week.
						$week_total[$this_month][1] = $week_total[$this_month][1] + $temp_total_time1;
						$week_total[$this_month][2] = $week_total[$this_month][2] + $temp_total_time2;
						$week_total[$this_month][3] = $week_total[$this_month][3] + $temp_total_time3;
						$week_total[$this_month][4] = $week_total[$this_month][4] + $temp_total_time4;
					}
					else {
						$attendance_card = $attendance_card . '<td class = "leftborder_dark_only"> </td><td> </td><td> </td><td> </td>';
					}
				}
				// For the 6th month, print empty cells.
				$attendance_card = $attendance_card . '<td class = "leftborder_dark_only"> </td><td> </td><td> </td><td> </td></tr>';
			}
			$attendance_card = $attendance_card . '</table>';
			// Print the totals for each week in a separate table.
			$attendance_card = $attendance_card . student_info::get_individual_totals_header('Fall');
			$attendance_card = $attendance_card . '<tr class="fontfordates"><td><center><b>Dates</b></center></td>';
			for ($m = 1; $m <= 5; $m++) {
				$attendance_card = $attendance_card . '<td class = "leftborder_dark_only"><div>' . $week_dates[$m][1] . '</div></td><td><div>' .  $week_dates[$m][2] .
					'</div></td><td><div>' .  $week_dates[$m][3] . '</div></td><td><div>' .  $week_dates[$m][4] . '</div></td>';
			}
			$attendance_card = $attendance_card . '<td class = "leftborder_dark_only"></td><td></td><td></td><td></td>';
			$attendance_card = $attendance_card . '</tr>';
			// Print the total for each week. Adjust the total when necessary (3=>4, 4=>5, don't exceed total possible).
			// Adjust the totals first.
			for ($m = 1; $m <= 5; $m++) {
				for ($w = 1; $w <=4; $w++) {
					// Divide by 4 to convert total hours into days.
					$week_total[$m][$w] = intval($week_total[$m][$w]/4);
					// Make sure that the total days does not pass the total days possible for the week.
					if ($week_total[$m][$w] > $points_possible[$m][$w]) {
						$week_total[$m][$w] = $points_possible[$m][$w];
					}
				}
			}
			// Create the last 2 rows - attendance totals and total points possible.
			$attendance_card = $attendance_card . '<tr><td><center>Total Days Earned</center></td>';
			for ($m = 1; $m <= 5; $m++) {
				$attendance_card = $attendance_card . '<td class = "leftborder_dark_only">' . $week_total[$m][1] .'</td><td>' . $week_total[$m][2] .  '</td><td>' .
					$week_total[$m][3] . '</td><td>' . $week_total[$m][4] . '</td>';
			}
			$attendance_card = $attendance_card . '<td class = "leftborder_dark_only"></td><td></td><td></td><td></td></tr><tr class="maxpoints"><td><center>Maximum Days Possible</center></td>';
			for ($m = 1; $m <= 5; $m++) {
				$attendance_card = $attendance_card . '<td class = "leftborder_dark_only">' . $points_possible[$m][1] .'</td><td>' . $points_possible[$m][2] .  '</td><td>' .
				$points_possible[$m][3] . '</td><td>' . $points_possible[$m][4] . '</td>';
			}
			$attendance_card = $attendance_card . '<td class = "leftborder_dark_only"></td><td></td><td></td><td></td></tr></table>';
			return $attendance_card;
		}
		else {
			// Spring Term - Initialize count for the weekly totals.
			for ($init_month = 6; $init_month <= 11; $init_month++) {
				for ($init_week = 1; $init_week <= 4; $init_week++) {
					$week_total[$init_month][$init_week] = 0;
				}
			}
			// Print the student courses with the weeks attendance credit - Months 6-11.
			for ($course_count = 1; $course_count <= $number_of_courses; $course_count++) {
				$attendance_card = $attendance_card . '<tr><td>' . $course_count . '</td>' .
				'<td class="leftborder_dark_only">' . $this_student_courses[$course_count]->course_name . ' [' . $this_student_courses[$course_count]->credits . ']</td>' .
				'<td>' .$this_student_courses [$course_count]->teacher . '</td>';
				for ($this_month = 6; $this_month <= 11; $this_month++) {
					// Get the students that already have attendance recorded.
					$table = 'istudy_monthatten';
					$select = "course = :course AND teacher_id = :teacher_id AND student_id = :student_id AND month = :month";
					$params =['course'=> $this_student_courses[$course_count]->courseid, 'teacher_id'=>$this_student_courses[$course_count]->teacherid, 'student_id'=>$this_studentid, 'month'=>$this_month];
					if ($studentattendance = $DB->get_record_select($table, $select, $params)) {
						// Get the synchronous (seat time) time for each student.
						$temp_sychronous_time1 = utils::get_synchronous_time($this_studentid, $studentattendance->teacher_id, $studentattendance->course, $month_info[$this_month]->week01date);
						$temp_sychronous_time2 = utils::get_synchronous_time($this_studentid, $studentattendance->teacher_id, $studentattendance->course, $month_info[$this_month]->week02date);
						$temp_sychronous_time3 = utils::get_synchronous_time($this_studentid, $studentattendance->teacher_id, $studentattendance->course, $month_info[$this_month]->week03date);
						$temp_sychronous_time4 = utils::get_synchronous_time($this_studentid, $studentattendance->teacher_id, $studentattendance->course, $month_info[$this_month]->week04date);
						// Get the total of hours for assignments turned in and hours for synchronous time.
						$temp_total_time1 = $studentattendance->creditsweek1 + $temp_sychronous_time1;
						$temp_total_time2 = $studentattendance->creditsweek2 + $temp_sychronous_time2;
						$temp_total_time3 = $studentattendance->creditsweek3 + $temp_sychronous_time3;
						$temp_total_time4 = $studentattendance->creditsweek4 + $temp_sychronous_time4;
						// Print a checkmark if hours work this course (this week) is 4 hours or more.
						$attendance_card = $attendance_card . '<td class = "leftborder_dark_only"><center>' . student_info::four_hours_or_more($temp_total_time1) . '</center></td>';
						$attendance_card = $attendance_card . '<td><center>' . student_info::four_hours_or_more($temp_total_time2) . '</center></td>';
						$attendance_card = $attendance_card . '<td><center>' . student_info::four_hours_or_more($temp_total_time3) . '</center></td>';
						$attendance_card = $attendance_card . '<td><center>' . student_info::four_hours_or_more($temp_total_time4) . '</center></td>';
						// Add the hours to the total hours for all courses each week.
						$week_total[$this_month][1] = $week_total[$this_month][1] + $temp_total_time1;
						$week_total[$this_month][2] = $week_total[$this_month][2] + $temp_total_time2;
						$week_total[$this_month][3] = $week_total[$this_month][3] + $temp_total_time3;
						$week_total[$this_month][4] = $week_total[$this_month][4] + $temp_total_time4;
					}
					else {
						$attendance_card = $attendance_card . '<td class="leftborder_dark_only"> </td><td> </td><td> </td><td> </td>';
					}
				}
				$attendance_card = $attendance_card . '</tr>';
			}
			// Print the total for each week. Adjust the total when necessary (3=>4, 4=>5, don't exceed total possible).
			// Adjust the totals first.
			for ($m = 6; $m <= 11; $m++) {
				for ($w = 1; $w <=4; $w++) {
					// Divide by 4 to convert total hours into days.
					$week_total[$m][$w] = intval($week_total[$m][$w]/4);
					// Make sure that the total days does not pass the total days possible for the week.
					if ($week_total[$m][$w] > $points_possible[$m][$w]) {
						$week_total[$m][$w] = $points_possible[$m][$w];
					}
				}
			}
			// Create the last 2 rows - attendance totals and total points possible.
			$attendance_card = $attendance_card . '<tr class="monthtotals"><td colspan="3"><center>Total Days Earned</center></td>';
			for ($m = 6; $m <= 11; $m++) {
				$attendance_card = $attendance_card . '<td class="leftborder_dark_only"><center>' . $week_total[$m][1] .'</center></td><td><center>' . $week_total[$m][2] .  '</center></td><td><center>' .
					$week_total[$m][3] . '</center></td><td><center>' . $week_total[$m][4] . '</center></td>';
			}
			$attendance_card = $attendance_card . '</tr><tr class="maxpoints"><td colspan="3"><center>Maximum Days Possible</center></td>';
			for ($m = 6; $m <= 11; $m++) {
				$attendance_card = $attendance_card . '<td class="leftborder_dark_only"><center>' . $points_possible[$m][1] .'</center></td><td><center>' . $points_possible[$m][2] .  '</center></td><td><center>' .
				$points_possible[$m][3] . '</center></td><td><center>' . $points_possible[$m][4] . '</center></td>';
			}
			// Print the totals for each week in a separate table.
			$attendance_card = $attendance_card . '<tr class="fontfordates"><th colspan="3"><center><b>Dates</b></center></th>';
			for ($m = 6; $m <= 11; $m++) {
				$attendance_card = $attendance_card . '<th class="leftborder_dark_only"><div>' . $week_dates[$m][1] . '</div></th><th><div>' .  $week_dates[$m][2] .
					'</div></th><th><div>' .  $week_dates[$m][3] . '</div></th><th><div>' .  $week_dates[$m][4] . '</div></th>';
			}
			$attendance_card = $attendance_card . '</tr></table></body></html>';
			return $attendance_card;
		}
	}

	// For the current month, find the start date and points possible for each week (4 weeks).
	public static function get_month_info($school_month) {
		if ($school_month < 10) {
			$school_month_temp = 'month0' . $school_month;
		}
		else {
			$school_month_temp = 'month' . $school_month;
		}
		$month_info = new stdClass();
		$month_info->week01date = get_config('mod_istudy', $school_month_temp . 'week01date');
		$month_info->week02date = get_config('mod_istudy', $school_month_temp . 'week02date');
		$month_info->week03date = get_config('mod_istudy', $school_month_temp . 'week03date');
		$month_info->week04date = get_config('mod_istudy', $school_month_temp . 'week04date');
		$month_info->week01points = get_config('mod_istudy', $school_month_temp . 'week01');
		$month_info->week02points = get_config('mod_istudy', $school_month_temp . 'week02');
		$month_info->week03points = get_config('mod_istudy', $school_month_temp . 'week03');
		$month_info->week04points = get_config('mod_istudy', $school_month_temp . 'week04');
		// Find the beginning and the end of the current school year.
		$month_today = strval(date("m"));
		if ($month_today >= 7) {
			$year_start = strval(date("Y"));
		}
		else {
			$year_start = strval(date("Y")) - 1;
		}
		$year_end = $year_start + 1;
		$year_start_date = mktime(0,0,0,7,1,$year_start);
		$year_end_date = mktime(0,0,0,6,30,$year_end);
		$month_info->year_start = $year_start_date;
		$month_info->year_end = $year_end_date;
		return $month_info;
	}

	// Create and print attendance cards.
	public static function get_attendance_cards($submission, $attendanceform) {
		$school_month = $submission->schoolmonth;
		$student_count = $submission->studentcount;
		// Print attendance card == 1, print attendance for individual student == 2, print attendance summary == 3.
		if ($attendanceform == 1) {
			// Initialize student cards to empty.
			$student_cards = '';
			$month_info = new stdClass();
			$month_info = student_info::get_month_info($school_month);
			for ($i = 1; $i <= $student_count; $i++) {
			$this_studentid = $submission->{'student_chosen' . $i};
				if ($this_studentid > 0) {
					// Add a page break and a horizontal line before the next page, but do not add break if it's the first page.
					if ($student_cards <> '') {
						$student_cards = $student_cards . '<hr color="pink"><P style="page-break-before: always">';
					}
					$student_cards = $student_cards . student_info::get_studentcard($this_studentid, $school_month, $month_info);
				}
			}
			$attendance_print_newtab = "<script>
					var newWindow = window.open('iStudy');
					newWindow.document.write('$student_cards');
				</script>";
			echo $attendance_print_newtab;
		}
		// Print attendance for individual student == 2 - Print a list of students with their attendance totals for the semester.
		else if ($attendanceform == 2) {
			// Attendance individual report
			$attendance_individual = '';
			$count = 0;
			$this_term = utils::get_term($school_month);
			$current_year = utils::get_current_year($this_term);
			$week_totals = utils::get_week_totals($this_term);
			$week_dates = utils::get_week_dates($this_term);
			// For each month this semester, get the start date of each week and max week points (4 weeks).
			if ($school_month <=5) {
				for ($i = 1; $i <= 5; $i++) {
					$semester_month_info[$i] = new stdClass();
					$semester_month_info[$i] = student_info::get_month_info($i);
				}
			}
			else {
				for ($i = 6; $i <= 11; $i++) {
					$semester_month_info[$i] = new stdClass();
					$semester_month_info[$i] = student_info::get_month_info($i);
				}
			}
			// Create the attendance summary per page for each student chosen - includes the courses and semester attendance by work submitted.
			for ($i = 1; $i <= $student_count; $i++) {
				$this_studentid = $submission->{'student_chosen' . $i};
				if ($this_studentid > 0) {
					// Add a page break before the next page - do not add break if it's the first page.
					if ($attendance_individual <> '') {
					$attendance_individual = $attendance_individual . '<P style="page-break-before: always">';
					}
					$attendance_individual = $attendance_individual . student_info::get_courses_and_attendance($this_studentid, $this_term,
						$current_year, $week_totals, $week_dates, $semester_month_info);
				}
			}
			$attendance_print_newtab = "<script>
					var newWindow = window.open('iStudy');
					newWindow.document.write('$attendance_individual');
				</script>";
			echo $attendance_print_newtab;
			return;
		}
		else {
			// Attendance summary report
			$attendance_summary = '';
			$student_row_count = 0;
			$count = 0;
			$rows_per_page = 45;
			$temp_attendancesummary = new stdClass();
			$month_info = new stdClass();
			$month_info = student_info::get_month_info($school_month);
			for ($i = 1; $i <= $student_count; $i++) {
				// Prepare the first page.
				if ($attendance_summary == '') {
					// Title for the page
					$attendance_summary = $attendance_summary . '<link rel="stylesheet" type="text/css" href="styles-attendance_summary.css"><html><head><title>Attendance List</title></head><body><h1>' .
						get_config('mod_istudy', 'schoolname') . '</h1><h2>Summary - Assignment/Completion Record</h2>' .
						'<h3>Month ' . $school_month . '</h3>';
					// Table with the dates for each week and weekly points for this month
					$attendance_summary = $attendance_summary . '<table><tr><col width="25%"><col width="25%"><col width="25%"><col width="25%"><col width="25%">' .
						'<th></th><th><b>WEEK 1</b></th><th><b>WEEK 2</b></th><th><b>WEEK 3</b></th><th><b>WEEK 4</b></th></tr>' .
						'<tr><td><center><b>Date</b></center></td><td class = "center_the_cell">' . $month_info->week01date . '</td><td class = "center_the_cell">' . $month_info->week02date . '</td>' .
						'<td class = "center_the_cell">' . $month_info->week03date . '</td><td class = "center_the_cell">' . $month_info->week04date . '</td></tr>' .
						'<tr><td><center><b>Days</b></center></td><td class = "center_the_cell" class = "center_the_cell">' . $month_info->week01points . '</td><td class = "center_the_cell">' . $month_info->week02points . '</td>' .
						'<td class = "center_the_cell">' . $month_info->week03points . '</td><td class = "center_the_cell">' . $month_info->week04points . '</td></tr></table><br>';
					// Start the main table.
					$attendance_summary = $attendance_summary . '<table><tr><col width="3%"><col width="17%"><col width="13%"><col width="7%">' .
						'<col width="13%"><col width="7%"><col width="13%"><col width="7%"><col width="13%"><col width="7%">' .
						'<th><b>#</b></th><th><b>Student Name</b></th><th><b>Course</b></th><th><b>Wk 1-4</b></th><th><b>Course</b></th><th><b>Wk 1-4</b></th>' .
						'<th><b>Course</b></th><th><b>Wk 1-4</b></th><th><b>Course</b></th><th><b>Wk 1-4</b></th></tr>';
				}

				// Prepare a new page
				else if ($count >= $rows_per_page) {
					// Add a page break at before the next page.
					$attendance_summary = $attendance_summary . '</table></body></html><P style="page-break-before: always">';
					$count = 0;
					// Title for the page.
					$attendance_summary = $attendance_summary . '<link rel="stylesheet" type="text/css" href="styles-attendance_summary.css"><html><head><title>Attendance List</title></head><body><h1>' .
						get_config('mod_istudy', 'schoolname') . '</h1><h2>Summary - Assignment/Completion Record</h2>' .
						'<h3>Month ' . $school_month . '</h3>';
					// Table with the dates for each week and weekly points for this month.
					$attendance_summary = $attendance_summary . '<table><tr><col width="25%"><col width="25%"><col width="25%"><col width="25%"><col width="25%">' .
						'<th></th><th><b>WEEK 1</b></th><th><b>WEEK 2</b></th><th><b>WEEK 3</b></th><th><b>WEEK 4</b></th></tr>' .
						'<tr><td><center><b>Date</b></center></td><td class = "center_the_cell">' . $month_info->week01date . '</td><td class = "center_the_cell">' . $month_info->week02date . '</td>' .
						'<td class = "center_the_cell">' . $month_info->week03date . '</td><td class = "center_the_cell">' . $month_info->week04date . '</td></tr>' .
						'<tr><td><center><b>Days</b></center></td><td class = "center_the_cell" class = "center_the_cell">' . $month_info->week01points . '</td><td class = "center_the_cell">' . $month_info->week02points . '</td>' .
						'<td class = "center_the_cell">' . $month_info->week03points . '</td><td class = "center_the_cell">' . $month_info->week04points . '</td></tr></table><br>';
					// Start the main table.
					$attendance_summary = $attendance_summary . '<table><tr><col width="3%"><col width="17%"><col width="13%"><col width="7%">' .
						'<col width="13%"><col width="7%"><col width="13%"><col width="7%"><col width="13%"><col width="7%">' .
						'<th><b>#</b></th><th><b>Student Name</b></th><th><b>Course</b></th><th><b>Wk 1-4</b></th><th><b>Course</b></th><th><b>Wk 1-4</b></th>' .
						'<th><b>Course</b></th><th><b>Wk 1-4</b></th><th><b>Course</b></th><th><b>Wk 1-4</b></th></tr>';
				}
				$this_studentid = $submission->{'student_chosen' . $i};
				if ($this_studentid > 0) {
					$student_row_count = $student_row_count + 1;
					$temp_attendancesummary = student_info::get_attendancesummary($this_studentid, $school_month, $month_info, $student_row_count);
					$count = $count + $temp_attendancesummary->rows_used;
					$attendance_summary = $attendance_summary .	$temp_attendancesummary->mystudent_info;
				}
			}
			// If printing the last page, close the table.
			if ($count <= $rows_per_page) {
				$attendance_summary = $attendance_summary . '</table></body></html>';
			}
			// Print the attendance summary to a new tab.
			$attendance_print_newtab = "<script>
					var newWindow = window.open('iStudy');
					newWindow.document.write('$attendance_summary');
				</script>";
			echo $attendance_print_newtab;
		return;
		}
	}
}