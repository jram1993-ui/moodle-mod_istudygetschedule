<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * @package    mod_istudyprintattendanc
 * @copyright  2024 Jesus Ramirez <jram1993@gmail.com>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace mod_istudyprintattendanc;

use stdClass;

/**
 * Class utils
 *
 * @package    mod_istudyprintattendanc
 * @copyright  2024 Jesus Ramirez <jram1993@gmail.com>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

class utils {

	// Remove extra characters from the string.
	public static function remove_extra_symbols($snip) {
		$snip = str_replace("'", "’", $snip); // remove apostrophe
		$snip = str_replace("\t", '', $snip); // remove tabs
		$snip = str_replace("\r\n", '<br>', $snip); // remove new lines
		$snip = str_replace("\n", '<br>', $snip); // remove new lines
		$snip = str_replace("\r", '<br>', $snip); // remove carriage returns
		return $snip;
	}

	// Make sure that the date is not zero.
	public static function check_date($submission) {
		if ($submission > 0) {
			return date("m-d-Y", $submission);
		}
		else {
			return '';
		}
	}

	// Replace the dash in advisor name with a comma.
	public static function put_comma_in_name($myteacher) {
		$postion = strrpos($myteacher,"-");
		$name_with_dash = substr($myteacher, $postion);
		$name_with_comma = ', ' . substr($name_with_dash,1);
		$new_name = str_replace($name_with_dash,$name_with_comma,$myteacher);
		return $new_name;
	}

	// Get the lastname search criteria.
	public static function get_lastnamesearch($lastnameinitial){
		if ($lastnameinitial < 27) {
			$lastname_criteria = chr($lastnameinitial + 96) . '%'; }
		else {$lastname_criteria = '%'; }

		return $lastname_criteria;
	}

	// Get the course details from the text - subject, teacher, section or course id, room number.
	public static function get_mycourse($mycourse) {
		$course_info = new stdClass();
		$course_info->subject = strstr($mycourse, '/', true);
		$mycourse = strstr($mycourse, "/");
		$mycourse = substr($mycourse, 1);
		$course_info->teacher = strstr($mycourse, '/', true);
		$mycourse = strstr($mycourse, "/");
		$mycourse = substr($mycourse, 1);
		$course_info->section = trim($mycourse);
		$course_info->room = teacher_info::get_advisor_room($course_info->teacher);
		return $course_info;
	}

	// Get the term that corresponds to the month attendance chosen (1-11).
	public static function get_term($school_month) {
		// Get the current term
		if ($school_month <= 5) {
			return 'Fall';
		}
		else {
			return 'Spring';
		}
	}

	// Get the year for the current term today.
	public static function get_current_year($this_term) {
		$current_month_now = strval(date("m"));
		$current_year = strval(date("Y"));
		if ($current_month_now >= 8 and $this_term == 'Spring') {
			$current_year = $current_year + 1;
		}
		else if ($current_month_now <= 7 and $this_term == 'Fall') {
			$current_year = $current_year - 1;
		}
		return $current_year;
	}

	// Get the total possible for each week.
	public static function get_week_totals($this_term) {
		if ($this_term == 'Fall') {
			$week_totals[][] = array ();
			for ($m = 1; $m <=5; $m++) {
				for ($w = 1; $w <= 4; $w++) {
					$month_credits_name = 'month0' . $m . 'week0' . $w;
					$week_totals[$m][$w] = get_config('mod_istudy', $month_credits_name);
				}
			}
		}
		else {
			$week_totals[][] = array ();
			for ($m = 6; $m <=11; $m++) {
				for ($w = 1; $w <= 4; $w++) {
					if ($m <= 9) {
						$month_credits_name = 'month0' . $m . 'week0' . $w;
					}
					else {
						$month_credits_name = 'month' . $m . 'week0' . $w;
					}
					$week_totals[$m][$w] = get_config('mod_istudy', $month_credits_name);
				}
			}
		}
		return $week_totals;
	}

	// Get the the dates for each week - set the dates up on a table row.
	public static function get_week_dates($this_term) {
		if ($this_term == 'Fall') {
			$week_dates[][] = array ();
			for ($m = 1; $m <=5; $m++) {
				for ($w = 1; $w <= 4; $w++) {
					// Convert the date to a MM/DD string (month and day only - remove the year).
					if ($m <= 9) {
						$month_date_name = 'month0' . $m . 'week0' . $w . 'date';
					}
					else {
						$month_date_name = 'month' . $m . 'week0' . $w . 'date';
					}
					$temp_date = strtotime(get_config('mod_istudy', $month_date_name));
					// If the date is not formatted correctly, make it an empty text.
					if ($temp_date > 0) {
						$week_dates[$m][$w] = date("m/d", $temp_date);
					}
					else {
						$week_dates[$m][$w] = '';
					}
				}
			}
			// Month 6 is empty. There is no month 6 for the fall semester.
			$week_dates[6][1] = '';
			$week_dates[6][2] = '';
			$week_dates[6][3] = '';
			$week_dates[6][1] = '';
		}
		else {
			$week_dates[][] = array ();
			for ($m = 6; $m <=11; $m++) {
				for ($w = 1; $w <= 4; $w++) {
					// Convert the date to a MM/DD string (month and day only - remove the year).
					if ($m <= 9) {
						$month_date_name = 'month0' . $m . 'week0' . $w . 'date';
					}
					else {
						$month_date_name = 'month' . $m . 'week0' . $w . 'date';
					}
					$temp_date = strtotime(get_config('mod_istudy', $month_date_name));
					// If the date is not formatted correctly, make it an empty text.
					if ($temp_date > 0) {
						$week_dates[$m][$w] = date("m/d", $temp_date);
					}
					else {
						$week_dates[$m][$w] = '';
					}
				}
			}

		}
		return $week_dates;
	}

	// Return this school year (2) or last school year (1).
	public static function get_schoolyear($schoolyear) {
		$currentmonth = date('m');
		$currentyear = date('Y');
		// If we are in the spring semester, set the year equal to the start of the school year (start of fall semester).
		if ($schoolyear==1) {
			$currentyear = $currentyear -1;
		}
		if ($currentmonth >7){
			$school_year = $currentyear . '-' . ($currentyear + 1);
		}
		else {
			$school_year = ($currentyear-1) . '-' . $currentyear;
		}
		return $school_year;
	}

	// Calculate the grade level from the graduation year.
	public static function get_gradelevel($grad_year) {
		$currentmonth = date('m');
		$currentyear = date('Y');
		if ($grad_year <= $currentyear) {
			$years_left = 0;
		}
		else if ($currentmonth > 7) {
			$years_left = $grad_year - ($currentyear + 1);
		}
		else {
			$years_left = $grad_year - $currentyear;
		}
		$my_grade_level = 12 - $years_left;
		return $my_grade_level;
	}

	// Get the user_info_field id to use in searching user_info_data.
	public static function get_fieldid($item_name) {
		global $DB;
		$item = $DB->get_record('user_info_field', ['shortname' => $item_name], 'id');
		return $item->id;
	}

	// Search user_info_data for student data using the student id and user_info_field id.
	public static function get_field_data($student_id, $itemid) {
		global $DB;
		if ($DB->record_exists('user_info_data', ['userid'=>$student_id, 'fieldid'=>$itemid])) {
			$search_results = $DB->get_record('user_info_data', ['userid'=>$student_id, 'fieldid'=>$itemid], 'data');
			return $search_results->data;
		}
		else {
			return '';
		}
	}

	// Get the week points. Adjust the points and then make sure that they have not gone over the limit for the week.
	public static function get_weekpoints($points_counted_hours, $points_limit_days) {
		$points_counted = new stdClass();
		$points_limit_hours = $points_limit_days * 4;
		$points_counted_days = intval($points_counted_hours / 4);
		//Adjust the number of hours.
		if ($points_counted_hours > $points_limit_hours) {
			$points_counted_hours = $points_limit_hours;
		}
		// Adjust the number of days.
		if ($points_counted_days > $points_limit_days) {
			$points_counted_days = $points_limit_days;
		}
		$points_counted->hours = $points_counted_hours;
		$points_counted->days = $points_counted_days;
		return $points_counted;
	}
	// Get the default month according to today's date.
	public static function get_defaultmonth() {
		$mymonth[2] = get_config('mod_istudy', 'month02week01date');
		$mymonth[3] = get_config('mod_istudy', 'month03week01date');
		$mymonth[4] = get_config('mod_istudy', 'month04week01date');
		$mymonth[5] = get_config('mod_istudy', 'month05week01date');
		$mymonth[6] = get_config('mod_istudy', 'month06week01date');
		$mymonth[7] = get_config('mod_istudy', 'month07week01date');
		$mymonth[8] = get_config('mod_istudy', 'month08week01date');
		$mymonth[9] = get_config('mod_istudy', 'month09week01date');
		$mymonth[10] = get_config('mod_istudy', 'month10week01date');
		$mymonth[11] = get_config('mod_istudy', 'month11week01date');
		$default_month = 1;
		// Get the date  today.
		$mydatetoday = time();
		// There are 86400 seconds in a day. Add 2 days so that the month will switch on the Wednesday of the first week of each month.
		$two_days = 86400+86400;
		for ($i = 2; $i <= 11; $i++) {
			if (((strtotime($mymonth[$i])+$two_days) < $mydatetoday) AND (strtotime($mymonth[$i])>0)) {
				$default_month = $i;
			}
		}
		return $default_month;
	}

	// Get the full name of the course using the course number.
	public static function get_course_name($courseid) {
        global $DB;
        $sql = "SELECT * FROM {istudycourse_hours} WHERE section = " . $courseid;
        $params = null;
        $this_course = $DB->get_record_sql($sql, $params);
        return $this_course->subject;
	}

	// Get the student synchronous class time for the week.
	public static function get_synchronous_time($student_id, $teacher_id, $courseid, $this_monday) {
		global $DB;
		// If $this_monday is not a valid date, return 0.
		if (!($this_monday > 0)) {
			return 0;
		}
		// Set up contant date and time variables.
		$four_days = 86400+86400+86400+86400;
		$this_monday = strtotime($this_monday);
		$this_friday = $this_monday + $four_days;
		$tardy_minutes = 0;
		if ($student_id > 0) {
			$table = 'istudy_dailyattend_enter';
			$select = "student_id = :student_id AND teacher_id = :teacher_id AND course = :course AND attendance_date >= :attendance_date1 AND attendance_date <= :attendance_date2 AND attendance_status >= :attendance_status";
			$params =['student_id'=>$student_id, 'teacher_id'=>$teacher_id, 'course'=>$courseid, 'attendance_date1'=>$this_monday, 'attendance_date2'=>$this_friday, 'attendance_status'=>2];
			if ($temp_attendance = $DB->get_records_select($table, $select, $params)) {
				$days_attended = 0;
				$days_tardy = 0;
				foreach ($temp_attendance AS $my_student) {
                    if ($my_student->attendance_status == 2 OR $my_student->attendance_status == 3) {
                        // The student was present.
                        $days_attended++;
                    }
                    else if ($my_student->attendance_status == 4) {
                        // The student was tardy.
                        $days_tardy++;
                    }
                }
				// Get the time assigned to this course.
				$sql = "SELECT * FROM {istudycourse_hours} WHERE section = " . $courseid;
				$params = null;
				$course_seat_time = $DB->get_record_sql($sql, $params)->hour_value;
				// Deduct time if tardy istudycourse_hours section(text), subject(text), hour_value(float).
				$actual_seat_time = $course_seat_time * $days_attended;
				$tardy_seat_time = ($course_seat_time - $tardy_minutes) * $days_tardy;
				$total_seat_time =$actual_seat_time + $tardy_seat_time;
				if ($total_seat_time > 0) {
					return $total_seat_time;
				}
				else {
					return 0;
				}
			}
			else {
				return 0;
			}
		}
		else {
			return 0;
		}
	}

	// Check to see is course is active. Compare the course id with all of the courses on the master list.
	public static function course_is_active($courseid) {
		// Course master list - Convert the long string of courses into an array.
		$allcourses = get_config('mod_istudy', 'courselist');
		$complete_course_name = 'none';
		$count = 0;
		while(strlen($allcourses) > 0) {
			$count = $count + 1;
			$courselisttemp = strstr($allcourses, "\n", true);
			$courselist[$count] = $courselisttemp;
			$allcourses = strstr($allcourses, "\n");
			$allcourses = substr($allcourses, 1);
		}
		// Check to see if course is active. If found, return true.
		foreach ($courselist as $complete_course_name) {
			$course_info = utils::get_mycourse($complete_course_name);
			if ($course_info->section == $courseid) {
				return true;
			}
		}
		// The course was not found.
		return false;
	}

	// **Get the course id for the current session that the student is taking.
	public static function get_course_id($mycourse) {
		if ($mycourse == 'None') {
			return 'None';
		}
		else {
			$mycourse = strstr($mycourse, "/");
			$mycourse = substr($mycourse, 1);
			$mycourse = strstr($mycourse, "/");
			$mycourse = substr($mycourse, 1);
			$my_course_id = trim($mycourse);
			if ($my_course_id == '') {
				return 'None';
			}
			else {
				return $my_course_id;
			}
		}
	}
}