<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * English strings for istudyprintattendanc
 *
 * You can have a rather longer description of the file as well,
 * if you like, and it can span multiple lines.
 *
 * @package    mod_istudyprintattendanc
 * @copyright  2024 Jesus Ramirez <jram1993@gmail.com>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['modulename'] = 'istudyprintattendanc';
$string['modulenameplural'] = 'istudyprintattendancs';
$string['modulename_help'] = 'Use the istudyprintattendanc module for... | The istudyprintattendanc module allows...';
$string['istudyprintattendanc:addinstance'] = 'Add a new istudyprintattendanc';
$string['istudyprintattendanc:submit'] = 'Submit istudyprintattendanc';
$string['istudyprintattendanc:view'] = 'View istudyprintattendanc';
$string['istudyprintattendancfieldset'] = 'Custom example fieldset';
$string['istudyprintattendancname'] = 'istudyprintattendanc name';
$string['istudyprintattendancname_help'] = 'This is the content of the help tooltip associated with the istudyprintattendancname field. Markdown syntax is supported.';
$string['istudyprintattendanc'] = 'istudyprintattendanc';
$string['pluginadministration'] = 'istudyprintattendanc administration';
$string['pluginname'] = 'istudyprintattendanc';

// Choice of month labels
$string['monthpointsheading'] = 'Monthly Attendance Points';
$string['monthpointsheading_details'] = 'Enter the monthly attendance points';
$string['month01'] = 'Month 1';
$string['month02'] = 'Month 2';
$string['month03'] = 'Month 3';
$string['month04'] = 'Month 4';
$string['month05'] = 'Month 5';
$string['month06'] = 'Month 6';
$string['month07'] = 'Month 7';
$string['month08'] = 'Month 8';
$string['month09'] = 'Month 9';
$string['month10'] = 'Month 10';
$string['month11'] = 'Month 11';
$strint['description'] = 'Description';