<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Prints a particular instance of istudyprintattendanc
 *
 * You can have a rather longer description of the file as well,
 * if you like, and it can span multiple lines.
 *
 * @package    mod_istudyprintattendanc
 * @copyright  2024 Jesus Ramirez <jram1993@gmail.com>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

require(__DIR__.'/../../config.php');
require_once(__DIR__.'/lib.php');
require_once(__DIR__.'/choose_student_form.php');

global $DB, $USER;

/**
 * Course module id.
 */
$id = optional_param('id', 0, PARAM_INT);

/**
 * Activity instance id.
 */
$i = optional_param('i', 0, PARAM_INT);
if ($id) {
    $cm = get_coursemodule_from_id('istudyprintattendanc', $id, 0, false, MUST_EXIST);
    $course = $DB->get_record('course', array('id' => $cm->course), '*', MUST_EXIST);
    $moduleinstance = $DB->get_record('istudyprintattendanc', array('id' => $cm->instance), '*', MUST_EXIST);
} else {
    $moduleinstance = $DB->get_record('istudyprintattendanc', array('id' => $i), '*', MUST_EXIST);
    $course = $DB->get_record('course', array('id' => $moduleinstance->course), '*', MUST_EXIST);
    $cm = get_coursemodule_from_instance('istudyprintattendanc', $moduleinstance->id, $course->id, false, MUST_EXIST);
}
$istudyprintattendancid = $cm->instance;

require_login($course, true, $cm);

$modulecontext = \context_module::instance($cm->id);

$attendanceform = $USER->attendanceformpa;
$school_year = $USER->schoolyearpa;
$school_month = $USER->schoolmonthpa;
$advisor = mod_istudyprintattendanc\teacher_info::get_advisor($USER->advisorpa);
$lastnamesearch = mod_istudyprintattendanc\utils::get_lastnamesearch($USER->lastnamesearchpa);
$enrollment_status = $USER->enrollment_statuspa;

$PAGE->set_url('/mod/istudyprintattendanc/view.php', array('id' => $cm->id));
$PAGE->set_title(format_string($moduleinstance->name));
$PAGE->set_heading(format_string($course->fullname));
$PAGE->set_context($modulecontext);

// Output starts here.
echo $OUTPUT->header();

// Display form.
$formparams = array('schoolyear' => $school_year, 'schoolmonth' => $school_month, 'advisor' => $advisor,
	'lastnamesearch' => $lastnamesearch, 'enrollment_status' => $enrollment_status);
$mform = new mod_istudyprintattendanc_choose_student_form(null, $formparams);
$mform->set_data($istudyprintattendancid);
if ($mform->is_cancelled()) {
	// Cancelled forms redirect to the course main page.
	$url = new moodle_url('/course/view.php', array('id' => $course->id));
	redirect($url);
	return;
} else if ($data = $mform->get_data()) {
	// Make sure at least 1 student was chosen.
	$student_was_chosen = mod_istudyprintattendanc\student_info::get_student_chosen($data);
	if ($student_was_chosen) {
		// Get the course data.
		mod_istudyprintattendanc\student_info::get_attendance_cards($data, $attendanceform);
		// Changes have been saved - reload the page and output the message 'Changes Saved'.
		$USER->just_savedpa = 'Yes';
		$mform->reset_checkboxes($data);
	}
	else{
		$USER->just_savedpa = 'Error';
		$choose_studenturl = new moodle_url('/mod/istudyprintattendanc/choose_student.php', array('id' => $cm->id));
		redirect($choose_studenturl, 'THE ATTENDANCE IS BEING PREPARED', 0);
	}
} else {
	// Form has not been submitted or there was an error.
	// Just display the form.
	$mform->set_data(array('id' => $id));
}

// Finish the page.
if ($USER->just_savedpa == 'Yes') {
	echo $OUTPUT->notification('STUDENT ATTENDANCE HAS BEEN PRINTED - If attendance did not print, please turn off your popup blocker for this site', 'notifysuccess');
	$USER->just_savedpa = 'No';
}
elseif ($USER->just_savedpa == "Error") {
	echo $OUTPUT->notification('ERROR: Please choose at least 1 student.');
	$USER->just_savedsch = 'No';
}
$mform->display();
echo $OUTPUT->footer();