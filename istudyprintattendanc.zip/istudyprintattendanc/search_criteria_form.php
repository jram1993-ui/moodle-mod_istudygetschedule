<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * The main istudyprintattendanc configuration form
 *
 * It uses the standard core Moodle formslib. For more info about them, please
 * visit: http://docs.moodle.org/en/Development:lib/formslib.php
 *
 * @package    mod_istudyprintattendanc
 * @copyright  2024 Jesus Ramirez <jram1993@gmail.com>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

require_once($CFG->dirroot.'/lib/formslib.php');

/**
 * Module instance settings form
 *
 * @package    mod_istudyprintattendanc
 * @copyright  2024 Jesus Ramirez <jram1993@gmail.com>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class mod_istudyprintattendanc_search_criteria_form extends \moodleform
{
    public function definition()
	{
		$mform = $this->_form;
		$mform->addElement('html', '<table><tr><th colspan="14"><h3>Print Attendance Cards</h3>');
		$mform->addElement('html', '<h4>Refine Your Search</h4></th></tr>');
		$mform->addElement('html', '<link rel="stylesheet" type="text/css" href="styles-search_criteria_form.css">');

		// Choose the form that you are printing.
		$mform->addElement('html', '<tr><td class="mycell2">Which form are you printing?</td><td class="mycell3" colspan="4">');
		$mform->addElement('radio', 'whichform', '','Attendance Cards', 1);
		$mform->addElement('html', '</td><td class="mycell"  colspan="4">');
		$mform->addElement('radio', 'whichform', '','Student Semester Totals', 2);
		$mform->addElement('html', '</td><td class="mycell"  colspan="5">');
		$mform->addElement('radio', 'whichform', '','Attendance List (25 students per page)', 3);

		$mform->setDefault('whichform', 1);
		$mform->setType('whichform', PARAM_INT);
		$mform->addElement('html', '</td></tr>');

		// Choose the month (#1-11).
		for ($i = 1; $i <= 11; $i++) {
			if ($i <= 9) {
				$month_choice[$i] = get_string('month0' . $i, 'istudy') . ' - ' . get_config('mod_istudy', 'month0' . $i . 'week01date');
			}
			else {
				$month_choice[$i] = get_string('month' . $i, 'istudy') . ' - ' . get_config('mod_istudy', 'month' . $i . 'week01date');
			}
		}
		$mform->addElement('html', '<tr><td class="mycell2">Choose Month - Start Date</td><td class="mycell3" colspan="13">');
		$select = $mform->addElement('select', 'monthchoice', '', $month_choice);
		// Set default month.
		$select->setSelected(mod_istudyprintattendanc\utils::get_defaultmonth());
		$mform->addElement('html', '</td></tr>');

		// Choose the Advisory Teacher for option 1.
		$advisors = mod_istudyprintattendanc\teacher_info::get_advisors();
		$mform->addElement('html', '<tr><td class="mycell2">Choose All Advisors or a Specific Advisor</td><td colspan="13">');
		$select = $mform->addElement('select', 'advisor1', '', $advisors);
		// Set default to ALL teachers.
		$default_advisor = mod_istudyprintattendanc\teacher_info::get_default_advisor($advisors);
		$select->setSelected($default_advisor);
		// If ATTENDANCE CARDS is not chosen, disable advisor1.
		$mform->hideIf('advisor1', 'whichform', 'neq', 1);

		// Choose the Advisory Teacher for options 2 and 3.
		$advisors = mod_istudyprintattendanc\teacher_info::get_advisors();
		$select = $mform->addElement('select', 'advisor2', '', $advisors);
		// Set default to ALL teachers.
		$default_advisor = mod_istudyprintattendanc\teacher_info::get_default_advisor($advisors);
		$select->setSelected(0);
		// If ATTENDANCE CARDS is chosen, disable advisor2.
		$mform->hideIf('advisor2', 'whichform', 'eq', 1);

		$mform->addElement('html', '</td></tr>');

		// Choose active students (currently enrolled) or inactive students (dropped from the school).
		$enrollment_status = array(
			 1 => 'Active',
			 0 => 'Inactive',
		);
		$mform->addElement('html', '<tr><td class="mycell2">Choose according to enrollment status</td><td colspan="13">');
		$select = $mform->addElement('select', 'enrollment_status', '', $enrollment_status);
		// Set default to active.
		$select->setSelected(1);
		$mform->addElement('html', '</td></tr>');

		$mform->addElement('html', '<tr><td class="mycell" rowspan="3" valign="top">Choose All Students or by Last Name</td>');
		$mform->addElement('html', '<td colspan="2">');

		$mform->addElement('radio', 'lastnamesearch', '','ALL', 27, ['class' => 'radiobuttons-ALL']);
		$mform->addElement('html', '</td><td colspan="11"></td></tr><tr><td>');
		$mform->addElement('radio', 'lastnamesearch', '','A', 1, ['class' => 'radiobuttons-lastname']);
		$mform->addElement('html', '</td><td>');
		$mform->addElement('radio', 'lastnamesearch', '','B', 2, ['class' => 'radiobuttons-lastname']);
		$mform->addElement('html', '</td><td>');
		$mform->addElement('radio', 'lastnamesearch', '','C', 3, ['class' => 'radiobuttons-lastname']);
		$mform->addElement('html', '</td><td>');
		$mform->addElement('radio', 'lastnamesearch', '','D', 4, ['class' => 'radiobuttons-lastname']);
		$mform->addElement('html', '</td><td>');
		$mform->addElement('radio', 'lastnamesearch', '','E', 5, ['class' => 'radiobuttons-lastname']);
		$mform->addElement('html', '</td><td>');
		$mform->addElement('radio', 'lastnamesearch', '','F', 6, ['class' => 'radiobuttons-lastname']);
		$mform->addElement('html', '</td><td>');
		$mform->addElement('radio', 'lastnamesearch', '','G', 7, ['class' => 'radiobuttons-lastname']);
		$mform->addElement('html', '</td><td>');
		$mform->addElement('radio', 'lastnamesearch', '','H', 8, ['class' => 'radiobuttons-lastname']);
		$mform->addElement('html', '</td><td>');
		$mform->addElement('radio', 'lastnamesearch', '','I', 9, ['class' => 'radiobuttons-lastname']);
		$mform->addElement('html', '</td><td>');
		$mform->addElement('radio', 'lastnamesearch', '','J', 10, ['class' => 'radiobuttons-lastname']);
		$mform->addElement('html', '</td><td>');
		$mform->addElement('radio', 'lastnamesearch', '','K', 11, ['class' => 'radiobuttons-lastname']);
		$mform->addElement('html', '</td><td>');
		$mform->addElement('radio', 'lastnamesearch', '','L', 12, ['class' => 'radiobuttons-lastname']);
		$mform->addElement('html', '</td><td>');
		$mform->addElement('radio', 'lastnamesearch', '','M', 13, ['class' => 'radiobuttons-lastname']);
		$mform->addElement('html', '</td></tr><tr><td>');
		$mform->addElement('radio', 'lastnamesearch', '','N', 14, ['class' => 'radiobuttons-lastname']);
		$mform->addElement('html', '</td><td>');
		$mform->addElement('radio', 'lastnamesearch', '','O', 15, ['class' => 'radiobuttons-lastname']);
		$mform->addElement('html', '</td><td>');
		$mform->addElement('radio', 'lastnamesearch', '','P', 16, ['class' => 'radiobuttons-lastname']);
		$mform->addElement('html', '</td><td>');
		$mform->addElement('radio', 'lastnamesearch', '','Q', 17, ['class' => 'radiobuttons-lastname']);
		$mform->addElement('html', '</td><td>');
		$mform->addElement('radio', 'lastnamesearch', '','R', 18, ['class' => 'radiobuttons-lastname']);
		$mform->addElement('html', '</td><td>');
		$mform->addElement('radio', 'lastnamesearch', '','S', 19, ['class' => 'radiobuttons-lastname']);
		$mform->addElement('html', '</td><td>');
		$mform->addElement('radio', 'lastnamesearch', '','T', 20, ['class' => 'radiobuttons-lastname']);
		$mform->addElement('html', '</td><td>');
		$mform->addElement('radio', 'lastnamesearch', '','U', 21, ['class' => 'radiobuttons-lastname']);
		$mform->addElement('html', '</td><td>');
		$mform->addElement('radio', 'lastnamesearch', '','V', 22, ['class' => 'radiobuttons-lastname']);
		$mform->addElement('html', '</td><td>');
		$mform->addElement('radio', 'lastnamesearch', '','W', 23, ['class' => 'radiobuttons-lastname']);
		$mform->addElement('html', '</td><td>');
		$mform->addElement('radio', 'lastnamesearch', '','X', 24, ['class' => 'radiobuttons-lastname']);
		$mform->addElement('html', '</td><td>');
		$mform->addElement('radio', 'lastnamesearch', '','Y', 25, ['class' => 'radiobuttons-lastname']);
		$mform->addElement('html', '</td><td>');
		$mform->addElement('radio', 'lastnamesearch', '','Z', 26, ['class' => 'radiobuttons-lastname']);
		$mform->addElement('html', '</td></tr>');

		$mform->setDefault('lastnamesearch', 27);
		$mform->setType('lastnamesearch', PARAM_INT);
		$mform->addElement('html', '</table>');

		$mform->addElement('hidden', 'id');
        $mform->setType('id', PARAM_INT);
		$mform->addElement('html', '<br><h3>  </h3>');

		// Add standard buttons, common to all modules.
		$mform->addElement('html', '<div class="buttonsetup">');
			$this->add_action_buttons(true, 'Submit');
		$mform->addElement('html', '</div>');
    }
}